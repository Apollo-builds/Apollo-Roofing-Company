import { Link, createFileRoute, notFound, useNavigate } from '@tanstack/react-router'
import { ArrowLeft, Check, CreditCard, Lock } from 'lucide-react'
import { useEffect, useState } from 'react'
import { ClientOnly } from '#/components/ClientOnly'
import { DepositCardStep } from '#/components/checkout/DepositCardStep'
import { ElementsRoot, PayPanel } from '#/components/checkout/elements'
import {
  type SavedCard,
  clearCard,
  clearPendingCard,
  markCompleted,
  readCard,
  readPendingCard,
  saveCard,
} from '#/lib/checkout-state'
import { getSetupIntent } from '#/lib/deposit.functions'
import { formatMoney } from '#/lib/format'
import type { PlanView } from '#/lib/plans.functions'
import { pageHead } from '#/lib/seo'
import { productAttrs, productProps, trackOnce } from '#/lib/track'
import { usePlans } from '#/lib/use-plans'
import { getPlanConfig, siteConfig } from '#/site.config'

export const Route = createFileRoute('/checkout/$planKey')({
  staticData: { pageId: 'pg_c9Yw3KpL6Vnd' },
  beforeLoad: ({ params }) => {
    if (!getPlanConfig(params.planKey)) throw notFound()
  },
  head: ({ params }) => {
    const plan = getPlanConfig(params.planKey)
    return pageHead({
      title: `${plan?.summaryTitle ?? 'Checkout'} | ${siteConfig.shortName}`,
      description: plan?.blurb ?? siteConfig.seo.homeDescription,
      path: `/checkout/${params.planKey}`,
      noindex: true,
    })
  },
  notFoundComponent: CheckoutNotFound,
  component: CheckoutPage,
})

function CheckoutNotFound() {
  return (
    <section className="mx-auto max-w-2xl px-4 py-24 text-center">
      <h1 className="display text-5xl">We couldn't find that checkout</h1>
      <p className="mt-3 text-muted">The link may be out of date.</p>
      <Link to="/" hash="services" className="btn mt-8">
        See our services
      </Link>
    </section>
  )
}

function CheckoutPage() {
  const { planKey } = Route.useParams()
  const plan = usePlans().find((p) => p.key === planKey)
  if (!plan) return <CheckoutNotFound />

  return (
    <section className="mx-auto max-w-6xl px-4 py-10 sm:px-6 sm:py-14">
      <Link to="/" hash="services" className="inline-flex items-center gap-2 text-sm font-medium text-muted hover:text-accent">
        <ArrowLeft size={16} aria-hidden /> Back to services
      </Link>

      <div className="mt-6 grid gap-8 lg:grid-cols-[1fr_1.15fr] lg:items-start lg:gap-12">
        <OrderSummary plan={plan} />

        <div className="rounded-card border border-line bg-paper p-5 shadow-sm sm:p-8" data-testid="payment-panel">
          <ClientOnly fallback={<PanelSkeleton />}>
            <ElementsRoot>{plan.cardOnFile ? <DepositFlow plan={plan} /> : <PayStep plan={plan} />}</ElementsRoot>
          </ClientOnly>
        </div>
      </div>
    </section>
  )
}

function PanelSkeleton() {
  return (
    <div aria-hidden className="space-y-4">
      <div className="h-12 animate-pulse rounded bg-card" />
      <div className="h-12 animate-pulse rounded bg-card" />
      <div className="h-40 animate-pulse rounded bg-card" />
    </div>
  )
}

function OrderSummary({ plan }: { plan: PlanView }) {
  return (
    <aside
      {...productAttrs(plan)}
      data-testid="order-summary"
      className="rounded-card border border-line border-t-4 border-t-accent bg-card p-6 sm:p-8"
    >
      <p className="eyebrow">Order summary</p>
      <h1 className="display mt-2 text-4xl sm:text-5xl">{plan.summaryTitle}</h1>
      <p className="display mt-4 text-6xl text-accent">{formatMoney(plan.price, plan.currency)}</p>
      <p className="mt-3 text-muted">{plan.blurb}</p>

      <h2 className="display mt-8 text-2xl">What happens next</h2>
      <ol className="mt-3 space-y-3">
        {plan.next.map((line, i) => (
          <li key={line} className="flex gap-3">
            <span className="display grid size-7 shrink-0 place-items-center rounded-full bg-ink text-base text-paper">
              {i + 1}
            </span>
            <span className="pt-0.5">{line}</span>
          </li>
        ))}
      </ol>

      <p className="mt-8 flex items-center gap-2 border-t border-line pt-4 text-sm text-muted">
        <Lock size={15} aria-hidden /> Secure payment. One-time charge, no subscription.
      </p>
    </aside>
  )
}

/** Fires initiate_checkout once, then renders the express + full checkout. */
function PayStep({
  plan,
  buyerEmail,
  lockBuyerEmail,
  metadata,
}: {
  plan: PlanView
  buyerEmail?: string
  lockBuyerEmail?: boolean
  metadata?: Record<string, string>
}) {
  const navigate = useNavigate()

  useEffect(() => {
    trackOnce(`initiate_checkout:${plan.planId}`, 'initiate_checkout', productProps(plan))
  }, [plan])

  const returnUrl = `${window.location.origin}/thank-you?kind=${encodeURIComponent(plan.key)}`

  return (
    <PayPanel
      planId={plan.planId}
      returnUrl={returnUrl}
      metadata={metadata}
      buyerEmail={buyerEmail}
      lockBuyerEmail={lockBuyerEmail}
      onComplete={(paymentId) => {
        markCompleted({ kind: plan.key, paymentId, at: Date.now() })
        void navigate({ to: '/thank-you', search: { payment: paymentId, kind: plan.key } })
      }}
    />
  )
}

type Step = 'card' | 'pay'

/** Two-step deposit: (1) save a card on file with no charge, (2) pay the deposit. */
function DepositFlow({ plan }: { plan: PlanView }) {
  const [step, setStep] = useState<Step>('card')
  const [card, setCard] = useState<SavedCard | null>(null)
  const [skipped, setSkipped] = useState(false)
  const [notice, setNotice] = useState<string | null>(null)
  const [ready, setReady] = useState(false)
  const pending = typeof window !== 'undefined' ? readPendingCard() : null

  useEffect(() => {
    // Fires once when the deposit page opens.
    trackOnce('deposit_started', 'deposit_started', {
      value: plan.price,
      currency: 'USD',
      step: 'card_saved',
    })

    // Coming back from an off-site step (3-D Secure) with ?setup=sint_…&status=…
    const params = new URLSearchParams(window.location.search)
    const setupId = params.get('setup')
    const status = params.get('status')
    const saved = readCard()

    async function init() {
      if (setupId?.startsWith('sint_')) {
        window.history.replaceState(null, '', window.location.pathname)
        if (status === 'succeeded' || status === 'processing') {
          const res = await getSetupIntent({ data: { id: setupId } })
          const p = readPendingCard()
          if (res.ok && res.intent.status === 'succeeded' && p) {
            const c: SavedCard = {
              email: p.email,
              name: p.name,
              memberId: res.intent.memberId,
              paymentMethodId: res.intent.paymentMethodId,
              setupIntentId: res.intent.id,
              paymentLabel: res.intent.paymentLabel,
            }
            saveCard(c)
            clearPendingCard()
            setCard(c)
            setStep('pay')
            return
          }
        }
        setNotice("Your card wasn't saved. Please try again, or skip this step.")
      } else if (saved) {
        setCard(saved)
        setStep('pay')
      }
    }
    void init().finally(() => setReady(true))
  }, [plan.price])

  const returnUrl = `${window.location.origin}/checkout/${plan.key}`

  if (!ready) return <PanelSkeleton />

  return (
    <div>
      <Stepper step={step} />

      {notice && (
        <p role="alert" className="mt-5 rounded border border-accent/40 bg-accent/10 px-3 py-2 text-sm font-medium">
          {notice}
        </p>
      )}

      {step === 'card' ? (
        <div className="mt-6">
          <h2 className="display text-3xl">Save your card on file (no charge)</h2>
          <p className="mb-5 mt-2 text-muted">
            So we can bill your final balance when the job is done. You can skip this and pay that balance from an
            invoice link instead.
          </p>
          <DepositCardStep
            returnUrl={returnUrl}
            initialName={pending?.name}
            initialEmail={pending?.email}
            onSaved={(c) => {
              setCard(c)
              setSkipped(false)
              setNotice(null)
              setStep('pay')
            }}
            onSkip={() => {
              setCard(null)
              setSkipped(true)
              setNotice(null)
              setStep('pay')
            }}
          />
        </div>
      ) : (
        <div className="mt-6">
          <h2 className="display text-3xl">Pay your deposit</h2>
          <div className="mb-5 mt-3 flex flex-wrap items-center justify-between gap-2 rounded border border-line bg-card px-4 py-3 text-sm">
            <span className="flex items-center gap-2">
              <CreditCard size={17} className="text-accent" aria-hidden />
              {card ? (
                <span>
                  Card on file{card.paymentLabel ? `: ${card.paymentLabel}` : ''} for <strong>{card.email}</strong>
                </span>
              ) : (
                <span>No card on file. Your final balance will come as an invoice link.</span>
              )}
            </span>
            <button
              type="button"
              className="text-link"
              onClick={() => {
                clearCard()
                setCard(null)
                setSkipped(false)
                setStep('card')
              }}
            >
              {card ? 'Change card' : 'Save a card'}
            </button>
          </div>
          <PayStep
            // Remount so a changed email / card gets a fresh checkout session.
            key={card?.setupIntentId ?? (skipped ? 'skipped' : 'none')}
            plan={plan}
            buyerEmail={card?.email}
            lockBuyerEmail={!!card}
            metadata={{
              project: 'deposit',
              ...(card ? { setup_intent_id: card.setupIntentId } : {}),
            }}
          />
        </div>
      )}
    </div>
  )
}

function Stepper({ step }: { step: Step }) {
  const items: { id: Step; label: string }[] = [
    { id: 'card', label: 'Save card on file' },
    { id: 'pay', label: 'Pay deposit' },
  ]
  const current = items.findIndex((i) => i.id === step)
  return (
    <ol className="flex items-center gap-3" aria-label="Deposit steps" data-testid="stepper">
      {items.map((item, i) => {
        const done = i < current
        const active = i === current
        return (
          <li key={item.id} className="flex flex-1 items-center gap-3" aria-current={active ? 'step' : undefined}>
            <span
              className={`display grid size-8 shrink-0 place-items-center rounded-full border-2 text-lg ${
                active || done ? 'border-accent bg-accent text-accent-ink' : 'border-line text-muted'
              }`}
            >
              {done ? <Check size={16} aria-hidden /> : i + 1}
            </span>
            <span className={`text-sm font-semibold ${active ? 'text-ink' : 'text-muted'}`}>{item.label}</span>
            {i < items.length - 1 && <span aria-hidden className="h-px flex-1 bg-line" />}
          </li>
        )
      })}
    </ol>
  )
}