import { HeadContent, Outlet, Scripts, createRootRoute } from '@tanstack/react-router'
import { TanStackRouterDevtoolsPanel } from '@tanstack/react-router-devtools'
import { TanStackDevtools } from '@tanstack/react-devtools'

import appCss from '../styles.css?url'
import { DebugPanel } from '#/components/DebugPanel'
import { Footer } from '#/components/Footer'
import { Header } from '#/components/Header'
import { getPlans, type PlanView } from '#/lib/plans.functions'
import { pageHead } from '#/lib/seo'
import { siteConfig } from '#/site.config'

const FONTS_HREF =
  'https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700&family=Barlow:wght@400;500;600&display=swap'

export const Route = createRootRoute({
  loader: async (): Promise<{ plans: PlanView[] }> => ({ plans: await getPlans() }),
  staleTime: 60_000,
  head: () => {
    const seo = pageHead({
      title: siteConfig.seo.homeTitle,
      description: siteConfig.seo.homeDescription,
      path: '/',
    })
    return {
      meta: [
        { charSet: 'utf-8' },
        { name: 'viewport', content: 'width=device-width, initial-scale=1' },
        { name: 'theme-color', content: '#0f2233' },
        ...seo.meta,
      ],
      links: [
        { rel: 'icon', type: 'image/png', href: siteConfig.images.logo },
        { rel: 'apple-touch-icon', href: siteConfig.images.logo },
        { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
        { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossOrigin: 'anonymous' },
        { rel: 'stylesheet', href: FONTS_HREF },
        { rel: 'stylesheet', href: appCss },
        ...seo.links,
      ],
    }
  },
  component: RootLayout,
  shellComponent: RootDocument,
})

function RootLayout() {
  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[200] focus:rounded focus:bg-accent focus:px-3 focus:py-2 focus:text-accent-ink"
      >
        Skip to content
      </a>
      <Header />
      <main id="main">
        <Outlet />
      </main>
      <Footer />
      <DebugPanel />
    </>
  )
}

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <TanStackDevtools
          config={{
            position: 'bottom-right',
          }}
          plugins={[
            {
              name: 'Tanstack Router',
              render: <TanStackRouterDevtoolsPanel />,
            },
          ]}
        />
        <Scripts />
      </body>
    </html>
  )
}
