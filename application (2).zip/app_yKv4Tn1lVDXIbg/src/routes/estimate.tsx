import { createFileRoute } from '@tanstack/react-router'
import { ContactDetails } from '#/components/EstimateSection'
import { EstimateForm } from '#/components/EstimateForm'
import { pageHead } from '#/lib/seo'
import { siteConfig } from '#/site.config'

export const Route = createFileRoute('/estimate')({
  staticData: { pageId: 'pg_e4Rk8TnW3Zpc' },
  head: () =>
    pageHead({
      title: siteConfig.seo.estimateTitle,
      description: siteConfig.seo.estimateDescription,
      path: '/estimate',
    }),
  component: EstimatePage,
})

function EstimatePage() {
  const c = siteConfig.contact
  return (
    <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20">
      <div className="max-w-2xl">
        <p className="eyebrow">{c.eyebrow}</p>
        <h1 className="display mt-3 text-5xl sm:text-6xl">{c.heading}</h1>
        <p className="mt-4 text-lg text-muted">{c.sub}</p>
      </div>
      <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_1.5fr] lg:items-start">
        <ContactDetails />
        <div className="rounded-card border border-line bg-card/60 p-6 sm:p-9">
          <EstimateForm idPrefix="estp" />
        </div>
      </div>
    </section>
  )
}
