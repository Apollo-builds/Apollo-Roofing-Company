import { Link, createFileRoute } from '@tanstack/react-router'
import { CircleAlert, CircleCheck, Clock, Info } from 'lucide-react'
import { useEffect, useState } from 'react'
import { readCompleted } from '#/lib/checkout-state'
import { pageHead } from '#/lib/seo'
import { usePlans } from '#/lib/use-plans'
import { getPlanConfig, siteConfig } from '#/site.config'

type ThankYouSearch = { payment?: string; kind?: string; status?: string }

export const Route = createFileRoute('/thank-you')({
  staticData: { pageId: 'pg_t2Hs7GbN5Xqe' },
  validateSearch: (search: Record<string, unknown>): ThankYouSearch => ({
    payment: typeof search.payment === 'string' ? search.payment : undefined,
    kind: typeof search.kind === 'string' ? search.kind : undefined,
    status: typeof search.status === 'string' ? search.status : undefined,
  }),
  head: () =>
    pageHead({
      title: `Thank you | ${siteConfig.shortName}`,
      description: siteConfig.checkout.thankYouBody,
      path: '/thank-you',
      noindex: true,
    }),
  component: ThankYou,
})

type Outcome = 'checking' | 'success' | 'pending' | 'failed' | 'unknown'

function ThankYou() {
  const { payment, kind, status } = Route.useSearch()
  const plan = usePlans().find((p) => p.key === kind)
  const [outcome, setOutcome] = useState<Outcome>('checking')

  useEffect(() => {
    // Success only when Whop says `succeeded`, or this browser just finished the
    // checkout (onComplete flag). A bare visit to this URL proves nothing.
    if (status === 'succeeded') return setOutcome('success')
    if (status === 'failed' || status === 'canceled') return setOutcome('failed')
    if (status) return setOutcome('pending')
    const done = readCompleted()
    const fresh = done && Date.now() - done.at < 6 * 60 * 60 * 1000
    if (fresh && (!kind || done.kind === kind) && (!payment || done.paymentId === payment)) {
      return setOutcome('success')
    }
    setOutcome('unknown')
  }, [status, kind, payment])

  const retryKind = getPlanConfig(kind ?? '') ? kind : undefined

  return (
    <section className="mx-auto max-w-3xl px-4 py-16 sm:px-6 sm:py-24" aria-live="polite">
      {outcome === 'checking' && <p className="text-muted">Checking your payment…</p>}

      {outcome === 'success' && (
        <div data-testid="thank-you-success">
          <CircleCheck className="text-accent" size={48} aria-hidden />
          <h1 className="display mt-4 text-5xl sm:text-6xl">{siteConfig.checkout.thankYouTitle}</h1>
          <p className="mt-3 text-lg text-muted">{siteConfig.checkout.thankYouBody}</p>
          {payment && <p className="mt-2 text-sm text-muted">Reference: {payment}</p>}

          {kind === 'deposit' ? (
            <>
              <p
                className="mt-8 rounded-card border border-line border-l-4 border-l-accent bg-card p-5 text-lg"
                data-testid="deposit-note"
              >
                {siteConfig.checkout.depositNote}
              </p>
              <HowItWorks />
            </>
          ) : (
            plan && (
              <div className="mt-8">
                <h2 className="display text-3xl">What happens next</h2>
                <ol className="mt-3 list-decimal space-y-2 pl-5 text-muted">
                  {plan.next.map((n) => (
                    <li key={n}>{n}</li>
                  ))}
                </ol>
              </div>
            )
          )}

          <Link to="/" className="btn mt-10">
            Back to home
          </Link>
        </div>
      )}

      {outcome === 'pending' && (
        <div data-testid="thank-you-pending">
          <Clock className="text-accent" size={48} aria-hidden />
          <h1 className="display mt-4 text-5xl">Your payment is processing</h1>
          <p className="mt-3 text-lg text-muted">
            Your bank hasn't confirmed it yet. You'll get a receipt by email once it clears. If you don't, call{' '}
            <a className="font-semibold underline" href={`tel:${siteConfig.phone.tel}`}>
              {siteConfig.phone.display}
            </a>
            .
          </p>
        </div>
      )}

      {(outcome === 'failed' || outcome === 'unknown') && (
        <div data-testid="thank-you-failed">
          <CircleAlert className="text-accent" size={48} aria-hidden />
          <h1 className="display mt-4 text-5xl">
            {outcome === 'failed' ? "Your payment didn't go through" : "We couldn't confirm a payment"}
          </h1>
          <p className="mt-3 text-lg text-muted">
            {outcome === 'failed'
              ? 'You have not been charged. You can try again with the same or a different payment method.'
              : 'There is no completed payment on this visit. If you were charged, call us and we will sort it out.'}
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3">
            {retryKind && (
              <Link to="/checkout/$planKey" params={{ planKey: retryKind }} className="btn">
                Try again
              </Link>
            )}
            <a className="text-link" href={`tel:${siteConfig.phone.tel}`}>
              Call {siteConfig.phone.display}
            </a>
          </div>
        </div>
      )}
    </section>
  )
}

function HowItWorks() {
  const e = siteConfig.process.explainer
  return (
    <aside className="mt-6 flex gap-4 rounded-card border border-line bg-paper p-6">
      <Info className="mt-1 hidden shrink-0 text-accent sm:block" size={24} aria-hidden />
      <div>
        <h2 className="display text-2xl">{e.heading}</h2>
        <div className="mt-2 space-y-2 text-muted">
          {e.body.map((p) => (
            <p key={p}>{p}</p>
          ))}
        </div>
      </div>
    </aside>
  )
}
