import { createFileRoute } from '@tanstack/react-router'
import { EstimateSection } from '#/components/EstimateSection'
import { FeatureSplit } from '#/components/FeatureSplit'
import { Financing } from '#/components/Financing'
import { Hero } from '#/components/Hero'
import { Process } from '#/components/Process'
import { Reviews } from '#/components/Reviews'
import { ServiceArea } from '#/components/ServiceArea'
import { Services } from '#/components/Services'
import { pageHead } from '#/lib/seo'
import { siteConfig } from '#/site.config'

export const Route = createFileRoute('/')({
  staticData: { pageId: 'pg_h7Qm2xVd9Lta' },
  head: () =>
    pageHead({
      title: siteConfig.seo.homeTitle,
      description: siteConfig.seo.homeDescription,
      path: '/',
    }),
  component: Home,
})

function Home() {
  return (
    <>
      <Hero />
      <Services />
      <FeatureSplit />
      <Process />
      <Financing />
      <Reviews />
      <ServiceArea />
      <EstimateSection />
    </>
  )
}
