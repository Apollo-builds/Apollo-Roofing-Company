import { createFileRoute } from '@tanstack/react-router'
import { KeyRound, LoaderCircle, Lock } from 'lucide-react'
import { useCallback, useEffect, useState, type FormEvent } from 'react'
import { readCard } from '#/lib/checkout-state'
import {
  type FinalInvoiceOutput,
  type InvoiceView,
  createFinalInvoice,
  listInvoices,
  unlockAdmin,
  voidInvoice,
} from '#/lib/invoices.functions'
import { formatMoney } from '#/lib/format'
import { pageHead } from '#/lib/seo'
import { siteConfig } from '#/site.config'

export const Route = createFileRoute('/admin/invoices')({
  staticData: { pageId: 'pg_a6Jd4MuR8Wzf' },
  head: () =>
    pageHead({
      title: `${siteConfig.admin.title} | ${siteConfig.shortName}`,
      description: 'Office use only.',
      path: '/admin/invoices',
      noindex: true,
    }),
  component: AdminInvoices,
})

const PASS_KEY = 'site:admin-passcode'

function AdminInvoices() {
  const [passcode, setPasscode] = useState<string | null>(null)
  const [checked, setChecked] = useState(false)

  useEffect(() => {
    try {
      setPasscode(window.sessionStorage.getItem(PASS_KEY))
    } catch {
      setPasscode(null)
    }
    setChecked(true)
  }, [])

  function lock() {
    try {
      window.sessionStorage.removeItem(PASS_KEY)
    } catch {
      /* ignore */
    }
    setPasscode(null)
  }

  return (
    <section className="mx-auto max-w-5xl px-4 py-12 sm:px-6 sm:py-16">
      <p className="eyebrow">Office use only</p>
      <h1 className="display mt-2 text-5xl sm:text-6xl">{siteConfig.admin.title}</h1>
      <p className="mt-3 max-w-2xl text-muted">
        After a job is complete, bill the remaining balance: either charge the card the customer saved with their
        deposit, or send them an invoice link to pay themselves.
      </p>

      {!checked ? null : passcode ? (
        <Console passcode={passcode} onLock={lock} />
      ) : (
        <Gate
          onUnlocked={(p) => {
            try {
              window.sessionStorage.setItem(PASS_KEY, p)
            } catch {
              /* ignore */
            }
            setPasscode(p)
          }}
        />
      )}
    </section>
  )
}

function Gate({ onUnlocked }: { onUnlocked: (passcode: string) => void }) {
  const [value, setValue] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  async function submit(e: FormEvent) {
    e.preventDefault()
    if (busy || !value) return
    setBusy(true)
    setError(null)
    try {
      const res = await unlockAdmin({ data: { passcode: value } })
      if (res.ok) onUnlocked(value)
      else setError(res.error)
    } catch {
      setError('Something went wrong. Try again.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <form onSubmit={submit} className="mt-10 max-w-md rounded-card border border-line bg-card p-6" data-testid="admin-gate">
      <label className="label" htmlFor="passcode">
        <KeyRound size={15} className="mr-1 inline align-[-2px]" aria-hidden /> Passcode
      </label>
      <input
        id="passcode"
        type="password"
        autoComplete="off"
        className="field"
        value={value}
        onChange={(e) => setValue(e.target.value)}
      />
      {error && (
        <p role="alert" className="mt-3 text-sm font-medium text-accent">
          {error}
        </p>
      )}
      <button type="submit" className="btn mt-4" disabled={busy || !value}>
        {busy ? <LoaderCircle size={18} className="animate-spin" aria-hidden /> : <Lock size={17} aria-hidden />}
        Unlock
      </button>
    </form>
  )
}

function Console({ passcode, onLock }: { passcode: string; onLock: () => void }) {
  const [recent, setRecent] = useState<InvoiceView[] | null>(null)
  const [recentError, setRecentError] = useState<string | null>(null)
  const [result, setResult] = useState<FinalInvoiceOutput | null>(null)

  const [email, setEmail] = useState('')
  const [memberId, setMemberId] = useState('')
  const [paymentMethodId, setPaymentMethodId] = useState('')
  const [amount, setAmount] = useState('')
  const [description, setDescription] = useState<string>(siteConfig.finalInvoice.defaultDescription)
  const [note, setNote] = useState('')
  const [dueDate, setDueDate] = useState('')
  const [mode, setMode] = useState<'auto' | 'manual'>('manual')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [prefilled, setPrefilled] = useState(false)

  const handleLocked = useCallback(
    (res: { ok: false; locked?: boolean }) => {
      if (res.locked) onLock()
    },
    [onLock],
  )

  const refresh = useCallback(async () => {
    try {
      const res = await listInvoices({ data: { passcode } })
      if (res.ok) {
        setRecent(res.data)
        setRecentError(null)
      } else {
        handleLocked(res)
        setRecentError(res.error)
      }
    } catch {
      setRecentError("Couldn't load invoices.")
    }
  }, [passcode, handleLocked])

  useEffect(() => {
    void refresh()
    // If this browser just saved a card for a deposit, prefill the customer.
    const card = readCard()
    if (card) {
      setEmail(card.email)
      if (card.memberId) setMemberId(card.memberId)
      if (card.paymentMethodId) setPaymentMethodId(card.paymentMethodId)
      setMode('auto')
      setPrefilled(true)
    }
  }, [refresh])

  async function submit(e: FormEvent) {
    e.preventDefault()
    if (busy) return
    setBusy(true)
    setError(null)
    setResult(null)
    try {
      const res = await createFinalInvoice({
        data: {
          passcode,
          email,
          memberId,
          amount: Number(amount),
          description,
          note,
          dueDate,
          mode,
          paymentMethodId,
        },
      })
      if (res.ok) {
        setResult(res.data)
        if (res.data.recent.length) setRecent(res.data.recent)
      } else {
        handleLocked(res)
        setError(res.error)
      }
    } catch {
      setError('Something went wrong creating the invoice.')
    } finally {
      setBusy(false)
    }
  }

  async function doVoid(inv: InvoiceView) {
    if (!window.confirm(`Void invoice ${inv.number}? The customer will no longer be able to pay it.`)) return
    const res = await voidInvoice({ data: { passcode, id: inv.id } })
    if (res.ok) await refresh()
    else {
      handleLocked(res)
      setRecentError(res.error)
    }
  }

  return (
    <div className="mt-10 space-y-12">
      <div className="grid gap-8 lg:grid-cols-[1.1fr_1fr]">
        <form onSubmit={submit} className="rounded-card border border-line bg-card p-6 sm:p-8" data-testid="invoice-form">
          <div className="flex items-center justify-between">
            <h2 className="display text-3xl">New final invoice</h2>
            <button type="button" className="text-link text-sm" onClick={onLock}>
              Lock
            </button>
          </div>
          {prefilled && (
            <p className="mt-2 text-sm text-muted">Prefilled from the card this browser just saved.</p>
          )}

          <div className="mt-5 grid gap-4">
            <div>
              <label className="label" htmlFor="inv-email">Customer email</label>
              <input id="inv-email" type="email" className="field" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div>
              <label className="label" htmlFor="inv-member">
                or member id <span className="font-normal text-muted">(optional, mber_…)</span>
              </label>
              <input id="inv-member" className="field" value={memberId} onChange={(e) => setMemberId(e.target.value)} />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="label" htmlFor="inv-amount">Final balance (USD)</label>
                <input id="inv-amount" inputMode="decimal" className="field" placeholder="0.00" value={amount} onChange={(e) => setAmount(e.target.value)} />
              </div>
              <div>
                <label className="label" htmlFor="inv-due">
                  Due date <span className="font-normal text-muted">(optional)</span>
                </label>
                <input id="inv-due" type="date" className="field" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
              </div>
            </div>
            <div>
              <label className="label" htmlFor="inv-desc">Line description</label>
              <input id="inv-desc" className="field" value={description} onChange={(e) => setDescription(e.target.value)} />
            </div>
            <div>
              <label className="label" htmlFor="inv-note">
                Note to customer <span className="font-normal text-muted">(optional)</span>
              </label>
              <textarea id="inv-note" className="field !min-h-20" value={note} onChange={(e) => setNote(e.target.value)} />
            </div>

            <fieldset>
              <legend className="label">How should we collect it?</legend>
              <div className="space-y-2">
                <label className="flex cursor-pointer gap-3 rounded border border-line bg-paper p-3">
                  <input type="radio" name="mode" className="mt-1 size-4 accent-accent" checked={mode === 'auto'} onChange={() => setMode('auto')} />
                  <span>
                    <strong>Auto-charge card on file</strong>
                    <span className="block text-sm text-muted">
                      Charges the card the customer saved with their deposit. Right away, or on the due date if one is
                      set.
                    </span>
                  </span>
                </label>
                <label className="flex cursor-pointer gap-3 rounded border border-line bg-paper p-3">
                  <input type="radio" name="mode" className="mt-1 size-4 accent-accent" checked={mode === 'manual'} onChange={() => setMode('manual')} />
                  <span>
                    <strong>Send invoice for manual payment</strong>
                    <span className="block text-sm text-muted">Emails the customer a link to review and pay it themselves.</span>
                  </span>
                </label>
              </div>
            </fieldset>

            {mode === 'auto' && (
              <div>
                <label className="label" htmlFor="inv-pm">
                  Payment method id <span className="font-normal text-muted">(optional, payt_…; defaults to their saved card)</span>
                </label>
                <input id="inv-pm" className="field" value={paymentMethodId} onChange={(e) => setPaymentMethodId(e.target.value)} />
              </div>
            )}
          </div>

          {error && (
            <p role="alert" className="mt-5 break-words rounded border border-accent/40 bg-accent/10 px-3 py-2 text-sm font-medium" data-testid="invoice-error">
              {error}
            </p>
          )}
          <button type="submit" className="btn mt-6" disabled={busy}>
            {busy ? (
              <>
                <LoaderCircle size={18} className="animate-spin" aria-hidden /> Working…
              </>
            ) : mode === 'auto' ? (
              'Create & charge'
            ) : (
              'Create & send invoice'
            )}
          </button>
        </form>

        <div>
          {result ? (
            <div className="rounded-card border border-line border-t-4 border-t-accent bg-paper p-6" data-testid="invoice-result">
              <h2 className="display text-3xl">Invoice created</h2>
              <dl className="mt-4 grid grid-cols-[auto_1fr] gap-x-4 gap-y-2 text-sm">
                <dt className="text-muted">Invoice id</dt>
                <dd className="break-all font-mono">{result.invoice.id}</dd>
                <dt className="text-muted">Number</dt>
                <dd>{result.invoice.number}</dd>
                <dt className="text-muted">Status</dt>
                <dd><StatusBadge status={result.invoice.status} /></dd>
                <dt className="text-muted">Total</dt>
                <dd className="font-semibold">{formatMoney(Number(result.invoice.total), result.invoice.currency)}</dd>
                <dt className="text-muted">Collection</dt>
                <dd>{result.mode === 'auto' ? 'Auto-charge saved card' : 'Invoice link sent'}</dd>
                {result.invoice.paymentMethodId && (
                  <>
                    <dt className="text-muted">Card</dt>
                    <dd className="break-all font-mono">{result.invoice.paymentMethodId}</dd>
                  </>
                )}
                {result.invoice.scheduledChargeAt && (
                  <>
                    <dt className="text-muted">Charges on</dt>
                    <dd>{new Date(result.invoice.scheduledChargeAt).toLocaleString()}</dd>
                  </>
                )}
                {result.invoice.checkoutLink && (
                  <>
                    <dt className="text-muted">Payment link</dt>
                    <dd className="break-all">
                      <a className="underline" href={result.invoice.checkoutLink} target="_blank" rel="noreferrer">
                        Open hosted invoice
                      </a>
                    </dd>
                  </>
                )}
              </dl>
            </div>
          ) : (
            <div className="rounded-card border border-dashed border-line p-6 text-muted">
              <h2 className="display text-2xl text-ink">Result</h2>
              <p className="mt-2 text-sm">
                The invoice id, status, total and payment link appear here after you create one.
              </p>
            </div>
          )}
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between">
          <h2 className="display text-3xl">Recent invoices</h2>
          <button type="button" className="text-link text-sm" onClick={() => void refresh()}>
            Refresh
          </button>
        </div>
        {recentError && <p className="mt-3 text-sm font-medium text-accent">{recentError}</p>}
        <div className="mt-4 overflow-x-auto rounded-card border border-line">
          <table className="w-full min-w-[40rem] text-left text-sm" data-testid="invoice-table">
            <thead className="bg-card font-display text-base uppercase tracking-wider">
              <tr>
                <th className="px-4 py-3">Invoice</th>
                <th className="px-4 py-3">Customer</th>
                <th className="px-4 py-3">Total</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Created</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {recent === null && (
                <tr>
                  <td className="px-4 py-4 text-muted" colSpan={6}>Loading…</td>
                </tr>
              )}
              {recent?.length === 0 && (
                <tr>
                  <td className="px-4 py-4 text-muted" colSpan={6}>No invoices yet.</td>
                </tr>
              )}
              {recent?.map((inv) => (
                <tr key={inv.id} className="border-t border-line">
                  <td className="px-4 py-3">
                    <div className="font-semibold">{inv.number}</div>
                    <div className="font-mono text-xs text-muted">{inv.id}</div>
                  </td>
                  <td className="px-4 py-3">{inv.email ?? '—'}</td>
                  <td className="px-4 py-3">{formatMoney(Number(inv.total), inv.currency)}</td>
                  <td className="px-4 py-3"><StatusBadge status={inv.status} /></td>
                  <td className="px-4 py-3 whitespace-nowrap">{new Date(inv.createdAt).toLocaleDateString()}</td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">
                    {inv.checkoutLink && (
                      <a className="mr-3 underline" href={inv.checkoutLink} target="_blank" rel="noreferrer">
                        Link
                      </a>
                    )}
                    {(inv.status === 'open' || inv.status === 'draft') && (
                      <button type="button" className="text-link text-sm" onClick={() => void doVoid(inv)}>
                        Void
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  const tone =
    status === 'paid'
      ? 'bg-ink text-paper'
      : status === 'open' || status === 'pending' || status === 'authorized'
        ? 'bg-accent/15 text-accent'
        : 'bg-line text-muted'
  return <span className={`inline-block rounded px-2 py-0.5 text-xs font-semibold uppercase tracking-wide ${tone}`}>{status}</span>
}
