// Minimal typing for the Cloudflare Workers runtime module used by server code.
declare module "cloudflare:workers" {
	export const env: Record<string, any>;
}
