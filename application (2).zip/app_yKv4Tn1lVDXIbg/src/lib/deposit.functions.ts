import { createServerFn } from "@tanstack/react-start";
import { siteConfig } from "#/site.config";

export type SetupIntentView = {
	id: string;
	status: "processing" | "succeeded" | "canceled" | "requires_action";
	clientSecret: string | null;
	memberId: string | null;
	paymentMethodId: string | null;
	/** e.g. "Visa •••• 4242", once a method is saved. */
	paymentLabel: string | null;
	error: string | null;
};

export type SetupIntentResult =
	| { ok: true; intent: SetupIntentView }
	| { ok: false; error: string };

type RawIntent = {
	id: string;
	status: SetupIntentView["status"];
	client_secret: string | null;
	member_id: string | null;
	payment_method_id: string | null;
	payment_instrument: { display_name?: string } | null;
	last_setup_error: { message?: string | null } | null;
	account_id: string | null;
};

function toView(i: RawIntent): SetupIntentView {
	return {
		id: i.id,
		status: i.status,
		clientSecret: i.client_secret,
		memberId: i.member_id,
		paymentMethodId: i.payment_method_id,
		paymentLabel: i.payment_instrument?.display_name ?? null,
		error: i.last_setup_error?.message ?? null,
	};
}

const clean = (v: unknown, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : "");

/**
 * Saves the card the buyer entered (via the payment element in setup mode) on
 * their Whop member for this business. Nothing is charged.
 */
export const createSetupIntent = createServerFn({ method: "POST" })
	.validator((input: unknown) => {
		const d = (input ?? {}) as Record<string, unknown>;
		return {
			confirmationToken: clean(d.confirmationToken, 200),
			email: clean(d.email, 200).toLowerCase(),
			returnUrl: clean(d.returnUrl, 2000),
		};
	})
	.handler(async ({ data }): Promise<SetupIntentResult> => {
		if (!data.confirmationToken.startsWith("ctok_")) {
			return { ok: false, error: "Missing card confirmation. Please try again." };
		}
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(data.email)) {
			return { ok: false, error: "Enter a valid email address." };
		}
		const { whopClient, describeError } = await import("./whop.server");
		try {
			const whop = await whopClient();
			const intent = await whop.setupIntents.create(
				{
					account_id: siteConfig.accountId,
					confirmation_token: data.confirmationToken,
					email: data.email,
					currency: "usd",
					return_url: data.returnUrl.startsWith("https://") ? data.returnUrl : null,
					metadata: { project: "deposit", source: "website-deposit-checkout" },
				},
				{ timeoutInSeconds: 20, maxRetries: 0 },
			);
			return { ok: true, intent: toView(intent as unknown as RawIntent) };
		} catch (err) {
			console.error("[createSetupIntent]", describeError(err));
			return { ok: false, error: "We couldn't save that card. Check the details and try again." };
		}
	});

/** Poll a setup intent until it settles. */
export const getSetupIntent = createServerFn({ method: "POST" })
	.validator((input: unknown) => {
		const d = (input ?? {}) as Record<string, unknown>;
		return { id: clean(d.id, 100) };
	})
	.handler(async ({ data }): Promise<SetupIntentResult> => {
		if (!data.id.startsWith("sint_")) return { ok: false, error: "Unknown setup." };
		const { whopClient, describeError } = await import("./whop.server");
		try {
			const whop = await whopClient();
			const intent = (await whop.setupIntents.retrieve(
				{ id: data.id },
				{ timeoutInSeconds: 10, maxRetries: 0 },
			)) as unknown as RawIntent;
			if (intent.account_id && intent.account_id !== siteConfig.accountId) {
				return { ok: false, error: "Unknown setup." };
			}
			return { ok: true, intent: toView(intent) };
		} catch (err) {
			console.error("[getSetupIntent]", describeError(err));
			return { ok: false, error: "We couldn't check your card yet. Please try again." };
		}
	});
