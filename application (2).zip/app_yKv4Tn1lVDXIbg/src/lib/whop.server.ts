// Server-only helpers. Import this ONLY from inside createServerFn handlers
// (the import of `cloudflare:workers` is dynamic so the client bundle never sees it).
import { WhopClient } from "@whop/sdk";

type Env = Record<string, any>;

/** The Worker's environment bindings (secrets, WHOP_API_ORIGIN, ...). */
export async function getEnv(): Promise<Env> {
	try {
		const mod = await import("cloudflare:workers");
		return mod.env ?? {};
	} catch {
		return typeof process !== "undefined" ? (process.env as Env) : {};
	}
}

/** SDK client. The platform injects the company API key at the network edge,
 *  so the app never holds a key. Server only. */
export async function whopClient(): Promise<WhopClient> {
	const env = await getEnv();
	return new WhopClient({
		token: env.WHOP_API_KEY ?? "",
		baseUrl: `${env.WHOP_API_ORIGIN ?? "https://api.whop.com"}/api/v1`,
	});
}

/** Constant-time string comparison (hashes both sides so length doesn't leak). */
export async function safeEqual(a: string, b: string): Promise<boolean> {
	const enc = new TextEncoder();
	const [ha, hb] = await Promise.all([
		crypto.subtle.digest("SHA-256", enc.encode(a)),
		crypto.subtle.digest("SHA-256", enc.encode(b)),
	]);
	const x = new Uint8Array(ha);
	const y = new Uint8Array(hb);
	let diff = 0;
	for (let i = 0; i < x.length; i++) diff |= x[i]! ^ y[i]!;
	return diff === 0;
}

/** Turn an SDK/API error into a short, safe, human-readable string. */
export function describeError(err: unknown): string {
	if (err && typeof err === "object") {
		const e = err as { message?: string; statusCode?: number; body?: unknown };
		const body = e.body as { error?: { type?: string; message?: string } } | undefined;
		const apiMessage = body?.error?.message;
		if (apiMessage) {
			return `${e.statusCode ? `HTTP ${e.statusCode} ` : ""}${body?.error?.type ?? ""}: ${apiMessage}`.trim();
		}
		return [e.statusCode ? `HTTP ${e.statusCode}` : "", (e.message ?? "").split("\n")[0], e.body ? safeJson(e.body) : ""]
			.filter(Boolean)
			.join(" — ");
	}
	return String(err);
}

function safeJson(v: unknown): string {
	try {
		return JSON.stringify(v).slice(0, 600);
	} catch {
		return "";
	}
}
