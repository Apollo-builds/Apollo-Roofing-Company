import { createServerFn } from "@tanstack/react-start";
import { siteConfig } from "#/site.config";

export type PlanView = {
	key: string;
	planId: string;
	productId: string;
	title: string;
	blurb: string;
	summaryTitle: string;
	cardOnFile: boolean;
	next: string[];
	/** Price in major units (dollars). */
	price: number;
	currency: string;
	/** true when the price was read from Whop, false when it fell back to config. */
	live: boolean;
};

function fromConfig(p: (typeof siteConfig.plans)[number]): PlanView {
	return {
		key: p.key,
		planId: p.planId,
		productId: p.productId,
		title: p.title,
		blurb: p.blurb,
		summaryTitle: p.summaryTitle,
		cardOnFile: p.cardOnFile,
		next: [...p.next],
		price: p.fallbackPrice,
		currency: "USD",
		live: false,
	};
}

/** Cache for a minute per isolate so every page view isn't an API round trip. */
let cache: { at: number; plans: PlanView[] } | null = null;
const TTL_MS = 60_000;

/**
 * Live plan prices from Whop (plans.retrieve per plan), falling back to the
 * config values when a plan can't be read, so the page never breaks.
 */
export const getPlans = createServerFn({ method: "GET" }).handler(
	async (): Promise<PlanView[]> => {
		if (cache && Date.now() - cache.at < TTL_MS) return cache.plans;
		const { whopClient } = await import("./whop.server");
		let whop: Awaited<ReturnType<typeof whopClient>> | null = null;
		try {
			whop = await whopClient();
		} catch {
			whop = null;
		}
		const plans = await Promise.all(
			siteConfig.plans.map(async (p): Promise<PlanView> => {
				const base = fromConfig(p);
				if (!whop) return base;
				try {
					const plan = await whop.plans.retrieve(
						{ id: p.planId },
						{ timeoutInSeconds: 4, maxRetries: 0 },
					);
					const price = Number(plan.initial_price);
					if (!Number.isFinite(price)) return base;
					return {
						...base,
						price,
						currency: String(plan.currency ?? "usd").toUpperCase(),
						live: true,
					};
				} catch (err) {
					console.warn(`[getPlans] ${p.planId} fell back to config price`, err instanceof Error ? err.message : err);
					return base;
				}
			}),
		);
		// Only cache a fully live answer; retry soon if anything fell back.
		if (plans.every((p) => p.live)) cache = { at: Date.now(), plans };
		return plans;
	},
);
