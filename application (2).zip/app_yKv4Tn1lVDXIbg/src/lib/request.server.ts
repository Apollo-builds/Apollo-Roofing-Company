// Server files import request helpers from here, never from
// @tanstack/react-start/server directly (dev server reload quirk).
export { getRequestHeader, getRequestUrl } from "@tanstack/react-start/server";
