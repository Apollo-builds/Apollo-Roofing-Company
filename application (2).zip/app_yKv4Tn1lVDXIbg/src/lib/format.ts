export function formatMoney(amount: number, currency = "USD"): string {
	const whole = Number.isInteger(amount);
	return new Intl.NumberFormat("en-US", {
		style: "currency",
		currency,
		minimumFractionDigits: whole ? 0 : 2,
		maximumFractionDigits: 2,
	}).format(amount);
}

/** Replace `{price}` / `{count}` style tokens in config copy. */
export function fill(template: string, values: Record<string, string | number>): string {
	return template.replace(/\{(\w+)\}/g, (_, k: string) => String(values[k] ?? ""));
}
