import { getRouteApi } from "@tanstack/react-router";
import type { PlanView } from "#/lib/plans.functions";

const rootApi = getRouteApi("__root__");

/** Live plan data (price per plan key), loaded once by the root route. */
export function usePlans(): PlanView[] {
	return rootApi.useLoaderData().plans;
}

export function usePlan(key: string): PlanView | undefined {
	return usePlans().find((p) => p.key === key);
}
