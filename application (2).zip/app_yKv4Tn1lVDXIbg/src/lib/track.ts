// Pixel event helper. The hosting layer injects the Whop pixel and page views;
// this only forwards custom events to `window.whop.track` when it exists.

export type TrackProps = Record<string, string | number | boolean | null | undefined>;

export type TrackedEvent = { name: string; props: TrackProps; at: number };

declare global {
	interface Window {
		whop?: { track?: (name: string, props?: Record<string, unknown>) => void };
		__trackLog?: TrackedEvent[];
	}
}

export const TRACK_EVENT = "site:track";

export function track(name: string, props: TrackProps = {}): void {
	if (typeof window === "undefined") return;
	const entry: TrackedEvent = { name, props, at: Date.now() };
	// Always keep a log so the ?debug=events panel (and tests) can verify events,
	// even when the pixel isn't present in a preview.
	(window.__trackLog ??= []).push(entry);
	window.dispatchEvent(new CustomEvent(TRACK_EVENT, { detail: entry }));
	if (import.meta.env.DEV) console.log("[whop.track]", name, props);
	try {
		window.whop?.track?.(name, props);
	} catch (err) {
		if (import.meta.env.DEV) console.warn("[whop.track] failed", err);
	}
}

const once = new Set<string>();
/** Fire an event only once per page load for a given key. */
export function trackOnce(key: string, name: string, props: TrackProps = {}): void {
	if (once.has(key)) return;
	once.add(key);
	track(name, props);
}

type ProductEventPlan = { planId: string; productId: string; price: number; currency: string };

/** Standard product props: variant_id (plan_), product_id (prod_), value, currency. */
export function productProps(plan: ProductEventPlan): TrackProps {
	return {
		variant_id: plan.planId,
		product_id: plan.productId,
		value: plan.price,
		currency: plan.currency || "USD",
	};
}

/** data-whop-* attributes marking an element as showing a product variant. */
export function productAttrs(plan: ProductEventPlan) {
	return {
		"data-whop-product-id": plan.productId,
		"data-whop-variant-id": plan.planId,
		"data-whop-price": String(plan.price),
		"data-whop-currency": plan.currency || "USD",
	} as const;
}
