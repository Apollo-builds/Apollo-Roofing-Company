import { createServerFn } from "@tanstack/react-start";
import { getPlanConfig, siteConfig } from "#/site.config";

export type InvoiceView = {
	id: string;
	number: string;
	status: string;
	total: string;
	currency: string;
	email: string | null;
	createdAt: string;
	dueAt: string | null;
	paidAt: string | null;
	checkoutLink: string | null;
	scheduledChargeAt: string | null;
	paymentMethodId: string | null;
	metadataType: string | null;
};

export type AdminResult<T> = { ok: true; data: T } | { ok: false; error: string; locked?: boolean };

type Whop = Awaited<ReturnType<typeof import("./whop.server").whopClient>>;

type RawInvoice = {
	id: string;
	number: string;
	status: string;
	total: { amount: string; currency: string };
	email_address: string | null;
	created_at: string;
	due_at: string | null;
	paid_at: string | null;
	checkout_link: string | null;
	scheduled_charge_at: string | null;
	payment_method_id: string | null;
	metadata?: Record<string, string>;
};

function toView(i: RawInvoice): InvoiceView {
	return {
		id: i.id,
		number: i.number,
		status: i.status,
		total: i.total.amount,
		currency: i.total.currency.toUpperCase(),
		email: i.email_address,
		createdAt: i.created_at,
		dueAt: i.due_at,
		paidAt: i.paid_at,
		checkoutLink: i.checkout_link,
		scheduledChargeAt: i.scheduled_charge_at,
		paymentMethodId: i.payment_method_id,
		metadataType: i.metadata?.type ?? null,
	};
}

const s = (v: unknown, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : "");

/** Checks the passcode against the ADMIN_PASSCODE secret. Never returns the secret. */
async function checkPasscode(passcode: string): Promise<{ ok: true } | { ok: false; error: string }> {
	const { getEnv, safeEqual } = await import("./whop.server");
	const env = await getEnv();
	const expected = typeof env.ADMIN_PASSCODE === "string" ? env.ADMIN_PASSCODE : "";
	if (!expected) return { ok: false, error: "Admin access isn't configured (ADMIN_PASSCODE is not set)." };
	const good = await safeEqual(passcode, expected);
	if (!good) {
		await new Promise((r) => setTimeout(r, 600)); // slow down guessing
		return { ok: false, error: "Wrong passcode." };
	}
	return { ok: true };
}

const passcodeOnly = (input: unknown) => {
	const d = (input ?? {}) as Record<string, unknown>;
	return { passcode: s(d.passcode, 200) };
};

/** Unlock check for the admin page. */
export const unlockAdmin = createServerFn({ method: "POST" })
	.validator(passcodeOnly)
	.handler(async ({ data }): Promise<AdminResult<true>> => {
		const check = await checkPasscode(data.passcode);
		return check.ok ? { ok: true, data: true } : { ok: false, error: check.error, locked: true };
	});

async function listRecent(whop: Whop): Promise<InvoiceView[]> {
	const page = await whop.invoices.list(
		{ account_id: siteConfig.accountId, first: 15, order: "created_at", direction: "desc" } as never,
		{ timeoutInSeconds: 10, maxRetries: 0 },
	);
	const rows: InvoiceView[] = [];
	for await (const inv of page) {
		rows.push(toView(inv as unknown as RawInvoice));
		if (rows.length >= 15) break;
	}
	return rows;
}

export const listInvoices = createServerFn({ method: "POST" })
	.validator(passcodeOnly)
	.handler(async ({ data }): Promise<AdminResult<InvoiceView[]>> => {
		const check = await checkPasscode(data.passcode);
		if (!check.ok) return { ok: false, error: check.error, locked: true };
		const { whopClient, describeError } = await import("./whop.server");
		try {
			return { ok: true, data: await listRecent(await whopClient()) };
		} catch (err) {
			console.error("[listInvoices]", describeError(err));
			return { ok: false, error: `Couldn't load invoices: ${describeError(err)}` };
		}
	});

export const voidInvoice = createServerFn({ method: "POST" })
	.validator((input: unknown) => {
		const d = (input ?? {}) as Record<string, unknown>;
		return { ...passcodeOnly(d), id: s(d.id, 100) };
	})
	.handler(async ({ data }): Promise<AdminResult<InvoiceView>> => {
		const check = await checkPasscode(data.passcode);
		if (!check.ok) return { ok: false, error: check.error, locked: true };
		if (!data.id) return { ok: false, error: "Missing invoice id." };
		const { whopClient, describeError } = await import("./whop.server");
		try {
			const inv = await (await whopClient()).invoices.void({ id: data.id }, { timeoutInSeconds: 15, maxRetries: 0 });
			return { ok: true, data: toView(inv as unknown as RawInvoice) };
		} catch (err) {
			console.error("[voidInvoice]", describeError(err));
			return { ok: false, error: `Couldn't void invoice: ${describeError(err)}` };
		}
	});

export type FinalInvoiceInput = {
	passcode: string;
	email: string;
	memberId: string;
	amount: number;
	description: string;
	note: string;
	dueDate: string;
	mode: "auto" | "manual";
	paymentMethodId: string;
};

export type FinalInvoiceOutput = {
	invoice: InvoiceView;
	mode: "auto" | "manual";
	memberId: string | null;
	paymentMethodId: string | null;
	recent: InvoiceView[];
};

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

/** Finds a member of this business by exact email. */
async function findMemberByEmail(whop: Whop, email: string): Promise<string | null> {
	const page = await whop.members.list(
		{ account_id: siteConfig.accountId, query: email, first: 5 },
		{ timeoutInSeconds: 10, maxRetries: 0 },
	);
	let seen = 0;
	for await (const m of page) {
		// Only trust an exact email match: `query` also fuzzy-matches names.
		if (m.email?.toLowerCase() === email.toLowerCase()) return m.id;
		if (++seen >= 5) break;
	}
	return null;
}

/** First saved payment method (card, usable off-session) on a member. */
async function findSavedPaymentMethod(whop: Whop, memberId: string): Promise<string | null> {
	const page = await whop.paymentMethods.list(
		{ member_id: memberId, future_usage: "off_session", first: 10 },
		{ timeoutInSeconds: 10, maxRetries: 0 },
	);
	for await (const pm of page) return (pm as unknown as { id: string }).id;
	return null;
}

export const createFinalInvoice = createServerFn({ method: "POST" })
	.validator((input: unknown): FinalInvoiceInput => {
		const d = (input ?? {}) as Record<string, unknown>;
		const amount = typeof d.amount === "number" ? d.amount : Number(d.amount);
		return {
			passcode: s(d.passcode, 200),
			email: s(d.email, 200).toLowerCase(),
			memberId: s(d.memberId, 100),
			amount: Number.isFinite(amount) ? Math.round(amount * 100) / 100 : 0,
			description: s(d.description, 1000) || siteConfig.finalInvoice.defaultDescription,
			note: s(d.note, 1000),
			dueDate: s(d.dueDate, 10),
			mode: d.mode === "auto" ? "auto" : "manual",
			paymentMethodId: s(d.paymentMethodId, 100),
		};
	})
	.handler(async ({ data }): Promise<AdminResult<FinalInvoiceOutput>> => {
		const check = await checkPasscode(data.passcode);
		if (!check.ok) return { ok: false, error: check.error, locked: true };

		if (!data.memberId && !EMAIL_RE.test(data.email)) {
			return { ok: false, error: "Enter the customer's email or their member id (mber_…)." };
		}
		if (data.memberId && !data.memberId.startsWith("mber_")) {
			return { ok: false, error: "Member ids start with mber_." };
		}
		if (!(data.amount >= 1) || data.amount > 250_000) {
			return { ok: false, error: "Amount must be between $1.00 and $250,000.00." };
		}
		let dueAt: string | null = null;
		if (data.dueDate) {
			if (!/^\d{4}-\d{2}-\d{2}$/.test(data.dueDate)) return { ok: false, error: "Due date must be a valid date." };
			const due = new Date(`${data.dueDate}T23:59:00Z`);
			if (Number.isNaN(due.getTime())) return { ok: false, error: "Due date must be a valid date." };
			dueAt = due.toISOString();
		}

		const plan = getPlanConfig(siteConfig.finalInvoice.productPlanKey);
		const { whopClient, describeError } = await import("./whop.server");
		let invoiceId: string | null = null;
		try {
			const whop = await whopClient();

			// Who is being billed.
			let memberId: string | null = data.memberId || null;
			if (!memberId && data.email) memberId = await findMemberByEmail(whop, data.email);

			// Auto-charge needs a member and a saved payment method.
			let paymentMethodId: string | null = null;
			if (data.mode === "auto") {
				if (!memberId) {
					return {
						ok: false,
						error: "No customer with that email has saved a card with us. Send an invoice link instead, or use their member id.",
					};
				}
				paymentMethodId = data.paymentMethodId || (await findSavedPaymentMethod(whop, memberId));
				if (!paymentMethodId) {
					return {
						ok: false,
						error: "No saved card found for this customer. Send an invoice link for manual payment instead.",
					};
				}
			}

			const created = await whop.invoices.create(
				{
					account_id: siteConfig.accountId,
					...(memberId ? { member_id: memberId } : { email_address: data.email }),
					items: [
						{
							quantity: 1,
							description: data.description,
							variant: {
								currency: "usd",
								initial_price: data.amount,
								title: siteConfig.finalInvoice.lineTitle,
								billing_type: "one_time",
								product_id: plan?.productId,
								force_create_new_plan: true,
							},
						},
					],
					due_at: dueAt,
					payment_method_id: paymentMethodId,
					metadata: { type: "final_balance", collection: data.mode },
					// `memo` is accepted by the live API; SDK 2.7's types predate it.
					...(data.note ? { memo: data.note } : {}),
				} as never,
				{ timeoutInSeconds: 20, maxRetries: 0 },
			);
			invoiceId = created.id;

			// Sending a draft that has a payment method charges it (right away, or at
			// due_at); without one it emails the payment link.
			const sent = await whop.invoices.send({ id: created.id }, { timeoutInSeconds: 30, maxRetries: 0 });
			let recent: InvoiceView[] = [];
			try {
				recent = await listRecent(whop);
			} catch {
				recent = [];
			}
			return {
				ok: true,
				data: {
					invoice: toView(sent as unknown as RawInvoice),
					mode: data.mode,
					memberId,
					paymentMethodId,
					recent,
				},
			};
		} catch (err) {
			const message = describeError(err);
			console.error("[createFinalInvoice]", message);
			// Don't leave a half-made draft behind.
			if (invoiceId) {
				try {
					await (await whopClient()).invoices.void({ id: invoiceId });
				} catch {
					/* best effort */
				}
			}
			return { ok: false, error: `Whop rejected the invoice: ${message}` };
		}
	});
