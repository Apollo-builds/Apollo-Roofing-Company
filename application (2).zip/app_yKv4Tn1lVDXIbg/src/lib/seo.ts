import { absoluteUrl, siteConfig } from "#/site.config";

type HeadInput = {
	title: string;
	description: string;
	path: string;
	/** Absolute-able path to the share image; defaults to the hero. */
	image?: string;
	noindex?: boolean;
};

/** Per-route <head>: title, description, Open Graph and Twitter tags. */
export function pageHead({ title, description, path, image, noindex }: HeadInput) {
	const img = absoluteUrl(image ?? siteConfig.images.hero);
	const url = absoluteUrl(path);
	const meta: Record<string, string>[] = [
		{ title },
		{ name: "description", content: description },
		{ property: "og:site_name", content: siteConfig.name },
		{ property: "og:type", content: "website" },
		{ property: "og:title", content: title },
		{ property: "og:description", content: description },
		{ property: "og:url", content: url },
		{ property: "og:image", content: img },
		{ name: "twitter:card", content: "summary_large_image" },
		{ name: "twitter:title", content: title },
		{ name: "twitter:description", content: description },
		{ name: "twitter:image", content: img },
	];
	if (noindex) meta.push({ name: "robots", content: "noindex, nofollow" });
	const links = siteConfig.siteUrl ? [{ rel: "canonical", href: url }] : [];
	return { meta, links };
}
