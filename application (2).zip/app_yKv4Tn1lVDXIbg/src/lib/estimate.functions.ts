import { createServerFn } from "@tanstack/react-start";
import { getPlanConfig, getServiceConfig, siteConfig } from "#/site.config";

export type EstimateInput = {
	name: string;
	email: string;
	phone: string;
	street: string;
	city: string;
	state: string;
	zip: string;
	service: string;
	details: string;
	contactPref: string;
	/** Honeypot: real visitors never fill this in. */
	website: string;
};

export type EstimateResult =
	| { ok: true; leadId: string; service: string }
	| { ok: false; error: string; fieldErrors?: Partial<Record<keyof EstimateInput, string>> };

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function str(v: unknown, max: number): string {
	return typeof v === "string" ? v.trim().slice(0, max) : "";
}

function parse(input: unknown): EstimateInput {
	const d = (input ?? {}) as Record<string, unknown>;
	return {
		name: str(d.name, 100),
		email: str(d.email, 200).toLowerCase(),
		phone: str(d.phone, 40),
		street: str(d.street, 120),
		city: str(d.city, 80),
		state: str(d.state, 2).toUpperCase(),
		zip: str(d.zip, 10),
		service: str(d.service, 40),
		details: str(d.details, 2000),
		contactPref: str(d.contactPref, 40),
		website: str(d.website, 200),
	};
}

export function validateEstimate(v: EstimateInput): Partial<Record<keyof EstimateInput, string>> {
	const e: Partial<Record<keyof EstimateInput, string>> = {};
	if (v.name.length < 2) e.name = "Please enter your full name.";
	if (!EMAIL_RE.test(v.email)) e.email = "Enter a valid email address.";
	const digits = v.phone.replace(/\D/g, "");
	if (digits.length < 10 || digits.length > 15) e.phone = "Enter a phone number with area code.";
	if (v.street.length < 3) e.street = "Enter the street address of the roof.";
	if (v.city.length < 2) e.city = "Enter a city.";
	if (!/^[A-Z]{2}$/.test(v.state)) e.state = "Use the 2-letter state code.";
	if (!/^\d{5}(-\d{4})?$/.test(v.zip)) e.zip = "Enter a 5-digit ZIP code.";
	if (!getServiceConfig(v.service)) e.service = "Choose a service.";
	if (!(siteConfig.contact.contactPreferences as readonly string[]).includes(v.contactPref)) {
		e.contactPref = "Choose how we should reach you.";
	}
	return e;
}

/**
 * Whop leads belong to a Whop user, and there is no API to create a user for a
 * stranger. So: use the visitor's own Whop user when their email already belongs
 * to a member of this business, otherwise record the lead on the business's own
 * user and keep the real contact details in the lead's metadata.
 */
async function resolveLeadUserId(
	whop: Awaited<ReturnType<typeof import("./whop.server").whopClient>>,
	email: string,
): Promise<{ userId: string; matchedMember: boolean }> {
	try {
		const page = await whop.members.list(
			{ account_id: siteConfig.accountId, query: email, first: 5 },
			{ timeoutInSeconds: 8, maxRetries: 0 },
		);
		let seen = 0;
		for await (const m of page) {
			// Only trust an exact email match: `query` also fuzzy-matches names.
			if (m.email?.toLowerCase() === email && m.user?.id) {
				return { userId: m.user.id, matchedMember: true };
			}
			if (++seen >= 5) break;
		}
	} catch (err) {
		console.warn("[submitEstimate] member lookup failed", err instanceof Error ? err.message : err);
	}
	const me = await whop.users.me({}, { timeoutInSeconds: 8, maxRetries: 0 });
	return { userId: me.id, matchedMember: false };
}

export const submitEstimate = createServerFn({ method: "POST" })
	.validator((input: unknown) => parse(input))
	.handler(async ({ data }): Promise<EstimateResult> => {
		// Honeypot: pretend success so bots learn nothing, but create nothing.
		if (data.website) return { ok: true, leadId: "lead_ignored", service: data.service };

		const fieldErrors = validateEstimate(data);
		if (Object.keys(fieldErrors).length) {
			return { ok: false, error: "Please fix the highlighted fields.", fieldErrors };
		}

		const service = getServiceConfig(data.service)!;
		const plan = getPlanConfig(service.planKey);
		const { whopClient, describeError } = await import("./whop.server");
		const { getRequestHeader } = await import("./request.server");

		const referrer = getRequestHeader("referer") || getRequestHeader("origin") || siteConfig.siteUrl || null;

		try {
			const whop = await whopClient();
			const { userId, matchedMember } = await resolveLeadUserId(whop, data.email);
			const lead = await whop.leads.create(
				{
					account_id: siteConfig.accountId,
					product_id: plan?.productId ?? null,
					referrer,
					user_id: userId,
					metadata: {
						source: "website-estimate-form",
						name: data.name,
						email: data.email,
						phone: data.phone,
						address: data.street,
						city: data.city,
						state: data.state,
						zip: data.zip,
						address_full: `${data.street}, ${data.city}, ${data.state} ${data.zip}`,
						service: service.key,
						service_title: service.title,
						details: data.details,
						preferred_contact: data.contactPref,
						matched_member: matchedMember,
					},
				},
				{ timeoutInSeconds: 10, maxRetries: 0 },
			);
			return { ok: true, leadId: lead.id, service: service.key };
		} catch (err) {
			console.error("[submitEstimate] lead creation failed:", describeError(err));
			return {
				ok: false,
				error: `We couldn't send your request just now. Please try again, or call ${siteConfig.phone.display}.`,
			};
		}
	});
