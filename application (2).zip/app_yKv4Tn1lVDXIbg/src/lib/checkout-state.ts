// Small sessionStorage helpers shared by the checkout and thank-you pages.
// Everything is guarded: storage can be blocked or unavailable (SSR, privacy mode).

const COMPLETED_KEY = "site:checkout-completed";
const CARD_KEY = "site:saved-card";
const PENDING_CARD_KEY = "site:pending-card";

export type CompletedCheckout = { kind: string; paymentId: string; at: number };

export type SavedCard = {
	email: string;
	name: string;
	memberId: string | null;
	paymentMethodId: string | null;
	setupIntentId: string;
	paymentLabel: string | null;
};

function read<T>(key: string): T | null {
	try {
		const raw = window.sessionStorage.getItem(key);
		return raw ? (JSON.parse(raw) as T) : null;
	} catch {
		return null;
	}
}

function write(key: string, value: unknown) {
	try {
		window.sessionStorage.setItem(key, JSON.stringify(value));
	} catch {
		/* ignore */
	}
}

function remove(key: string) {
	try {
		window.sessionStorage.removeItem(key);
	} catch {
		/* ignore */
	}
}

export const markCompleted = (c: CompletedCheckout) => write(COMPLETED_KEY, c);
export const readCompleted = () => read<CompletedCheckout>(COMPLETED_KEY);

export const saveCard = (c: SavedCard) => write(CARD_KEY, c);
export const readCard = () => read<SavedCard>(CARD_KEY);
export const clearCard = () => remove(CARD_KEY);

/** Name + email kept across an off-site (3-D Secure) redirect. */
export const savePendingCard = (c: { email: string; name: string }) => write(PENDING_CARD_KEY, c);
export const readPendingCard = () => read<{ email: string; name: string }>(PENDING_CARD_KEY);
export const clearPendingCard = () => remove(PENDING_CARD_KEY);
