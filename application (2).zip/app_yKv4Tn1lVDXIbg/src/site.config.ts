/**
 * Everything company-specific lives in this file.
 *
 * To rebrand: edit the values below (and swap the images in /public).
 * Nothing else in src/ names the company, its services, prices or plan ids.
 *
 * Items marked `[confirm]` are placeholders the owner still has to verify.
 */

// ─── Identity ────────────────────────────────────────────────────────────────
export const siteConfig = {
	name: "Apollo Roofing Company",
	shortName: "Apollo Roofing",
	tagline: "Honest roofing. Fair deposits. Finished right.",

	/** Absolute https origin of the published site, used for og:url / og:image.
	 *  Leave "" to emit relative URLs (previews). Set it once the domain is known. */
	siteUrl: "",

	/** Whop business (account) that owns the plans, leads and invoices. */
	accountId: "biz_b5tKRfWcJlOiPW",

	phone: { display: "(555) 013-0199", tel: "+15550130199" }, // [confirm]
	email: "hello@apolloroofing.example", // [confirm]
	license: "TX Lic. #RC-000000", // [confirm]
	hours: [
		{ days: "Mon–Fri", time: "7:00 am – 6:00 pm" },
		{ days: "Saturday", time: "8:00 am – 2:00 pm" },
		{ days: "Sunday", time: "Closed" },
	], // [confirm]
	/** Placeholder address; shown in the contact section and footer. */
	address: {
		line1: "123 Main Street",
		city: "Dallas",
		state: "TX",
		zip: "75201",
	}, // [confirm]

	images: {
		logo: "/logo.png", // square, ~1024px
		hero: "/hero.png", // 16:9
		heroAlt: "Roofers installing new shingles on a house at golden hour",
		inspection: "/inspection.png", // 4:3
		inspectionAlt: "Roof inspector checking shingles on a pitched roof",
	},

	// ─── Navigation ────────────────────────────────────────────────────────────
	nav: [
		{ label: "Services", hash: "services" },
		{ label: "How it works", hash: "process" },
		{ label: "Financing", hash: "financing" },
		{ label: "Reviews", hash: "reviews" },
		{ label: "Service area", hash: "service-area" },
		{ label: "Contact", hash: "estimate" },
	],
	estimateCta: "Request an Estimate",

	// ─── Hero ──────────────────────────────────────────────────────────────────
	hero: {
		eyebrow: "Residential roofing · Dallas–Fort Worth",
		headline: "A new roof, without the guesswork.",
		sub: "We inspect first, quote in writing, and ask for a fair deposit, not your whole budget up front. You pay the balance when the job is done.",
		/** `{price}` is replaced with the live price of `inspectionPlanKey`. */
		secondaryLabel: "Book a {price} inspection",
		secondaryPlanKey: "inspection",
	},

	// ─── Service area ──────────────────────────────────────────────────────────
	serviceArea: {
		heading: "Serving the Dallas–Fort Worth metro", // [confirm]
		cities: [
			"Dallas",
			"Plano",
			"Frisco",
			"McKinney",
			"Irving",
			"Arlington",
			"Fort Worth",
			"Garland",
			"Denton",
			"Richardson",
		],
		note: "We work within roughly a 40-mile radius of downtown Dallas. Outside the list? Ask. If we can get a crew there, we will.", // [confirm]
	},

	// ─── Whop plans ────────────────────────────────────────────────────────────
	// Create each plan in Whop (one-time, USD) and paste its ids here.
	// `fallbackPrice` is only used if Whop can't be reached: live prices come
	// from Whop (see src/lib/plans.functions.ts), so change prices in Whop.
	// `key` is the URL slug: /checkout/<key>.
	plans: [
		{
			key: "inspection",
			planId: "plan_FVUDTD8isN1bQ",
			productId: "prod_pUzKfMBxhLUg6",
			title: "Roof inspection",
			fallbackPrice: 149,
			blurb: "A full written roof inspection with photos and a repair-or-replace recommendation.",
			summaryTitle: "Roof inspection fee",
			cardOnFile: false,
			next: [
				"We confirm a time within one business day.",
				"A certified inspector walks the roof and takes photos.",
				"You get a written report and a firm estimate.",
			],
		},
		{
			key: "deposit",
			planId: "plan_t5Ir5k4TpSJay",
			productId: "prod_IaH6g6TD77IaI",
			title: "Project deposit",
			fallbackPrice: 500,
			blurb: "A fair deposit that reserves your crew and materials order.",
			summaryTitle: "Roof replacement deposit",
			/** true = checkout has a first step that saves a card on file (no charge). */
			cardOnFile: true,
			next: [
				"Your card is saved safely with Whop (no charge) so we can bill the final balance.",
				"The deposit reserves your install date and orders materials.",
				"When the job is complete, the remaining balance is billed from an itemized final invoice.",
			],
		},
		{
			key: "repair",
			planId: "plan_91x1yuvf4nPtK",
			productId: "prod_PrMP63ISeV3Ic",
			title: "Minor Roof Repair",
			fallbackPrice: 395,
			blurb: "Flat-rate repair for a leak, a few damaged shingles or failed flashing.",
			summaryTitle: "Minor Roof Repair (flat rate)",
			cardOnFile: false,
			next: [
				"We call you within one business day to schedule.",
				"A crew repairs the problem at the flat rate. No hourly surprises.",
				"If we find something bigger, we tell you before doing any extra work.",
			],
		},
	],

	/** Plan that the "final balance" invoice is attached to (admin invoices). */
	finalInvoice: {
		productPlanKey: "deposit",
		defaultDescription: "Final balance — roof replacement",
		lineTitle: "Final balance",
	},

	// ─── Services ──────────────────────────────────────────────────────────────
	// Rendered generically as cards. `planKey` points at an entry in `plans`.
	// `priceNote` replaces `{price}` with the live price of that plan.
	services: [
		{
			key: "repair",
			title: "Roof Repair",
			blurb: "Leaks, missing shingles and failed flashing, fixed properly the first time.",
			bullets: [
				"Leak tracing and sealing",
				"Shingle and flashing replacement",
				"Photos before and after",
				"Flat-rate pricing",
			],
			priceNote: "Minor repairs from {price} flat",
			planKey: "repair",
			cta: "Book a repair",
		},
		{
			key: "replacement",
			title: "Roof Replacement",
			blurb: "Full tear-off, new underlayment and a roof built to last, with a written warranty.",
			bullets: [
				"Complete tear-off and deck check",
				"Manufacturer-rated shingles and underlayment",
				"Cleanup with magnetic nail sweep",
				"10-year workmanship warranty",
			],
			priceNote: "{price} deposit reserves your install date",
			planKey: "deposit",
			cta: "Reserve with a deposit",
		},
		{
			key: "inspection",
			title: "Roof Inspection",
			blurb: "Know the true condition of your roof, and what it will cost, before you decide.",
			bullets: [
				"Full roof, flashing and attic check",
				"Photo report in writing",
				"Honest repair-or-replace advice",
				"Helps with insurance claims",
			],
			priceNote: "Inspection {price}",
			planKey: "inspection",
			cta: "Book an inspection",
		},
	],

	servicesSection: {
		eyebrow: "What we do",
		heading: "Three ways we help",
		sub: "Pick the one that fits. Prices are shown up front and come straight from our checkout.",
	},

	// Feature split under the services (image + text). `serviceKey` links to a service.
	feature: {
		serviceKey: "inspection",
		eyebrow: "Start here",
		heading: "Know what's up there before you spend on shingles.",
		body: "Most roofs don't need replacing, and some do. Our inspector walks the whole roof, checks the decking and attic where it matters, and hands you a photo report with a straight answer.",
		points: [
			"Written report with photos, usually within 24 hours",
			"A firm, itemized estimate if work is needed",
			"No pressure and no obligation to hire us",
		],
		cta: "Book an inspection",
	},

	// ─── Process ───────────────────────────────────────────────────────────────
	process: {
		eyebrow: "How it works",
		heading: "Four steps. No surprises.",
		steps: [
			{
				title: "Inspect",
				body: "We look at the roof and give you a written estimate.",
			},
			{
				title: "Deposit",
				body: "A fair deposit reserves your date and orders materials. Your card is saved securely, with no extra charge.",
			},
			{
				title: "Build",
				body: "Our crew tears off, rebuilds and cleans up, with photos along the way.",
			},
			{
				title: "Final invoice",
				body: "When the job is complete, we send an itemized invoice for the balance.",
			},
		],
		explainer: {
			heading: "How the deposit and final invoice work",
			body: [
				"At the deposit step, you save a card on file (nothing is charged) and pay your deposit through Whop's secure checkout.",
				"After the work is finished and you've signed off, we bill the final balance. Either to your saved card, or as an invoice link you can pay yourself.",
				"You'll always see the amount and a description before anything is charged.",
			],
		},
	},

	// ─── Financing ─────────────────────────────────────────────────────────────
	financing: {
		eyebrow: "Financing",
		heading: "Pay for your new roof over time",
		body: "At checkout, eligible buyers automatically see financing options such as Klarna, Afterpay or Splitit, offered through Whop when the merchant is approved. There's nothing extra to apply for on our site.",
		providers: ["Klarna", "Afterpay", "Splitit"],
		steps: [
			"Choose your plan at checkout.",
			"If you're eligible, financing options appear next to card and wallet payments.",
			"Pick the one that fits and finish in the same window.",
		],
		fineprint:
			"Financing is subject to approval and plan limits. Availability depends on the amount, your location and the provider. Not every buyer will see every option.",
	},

	// ─── Reviews & trust ───────────────────────────────────────────────────────
	reviews: {
		eyebrow: "Reviews",
		heading: "What homeowners say",
		/** SAMPLE DATA. These reviews and the rating are placeholders so the
		 *  layout can be judged. Replace with real, verifiable reviews, then set
		 *  `sample: false` to remove the on-page "sample" caption. */
		sample: true,
		rating: 4.9,
		count: 128,
		countLabel: "{count} reviews",
		items: [
			{
				name: "Marcus T.",
				place: "Plano, TX",
				text: "They found two spots the last company missed and quoted the job in writing the same day. The deposit was fair and the crew was done in two days.",
			},
			{
				name: "Elena R.",
				place: "Frisco, TX",
				text: "The inspection fee was worth it just for the photo report. We went with a repair instead of a new roof and saved thousands.",
			},
			{
				name: "Dale & Jo W.",
				place: "Arlington, TX",
				text: "Clean job site, honest pricing, and the final invoice matched the estimate to the dollar. Would hire again.",
			},
		],
	},
	trust: [
		{ icon: "shield", title: "Licensed & insured", body: "Fully licensed and carrying liability and workers' comp." },
		{ icon: "hammer", title: "10-year workmanship warranty", body: "Our labor is backed in writing." },
		{ icon: "award", title: "Manufacturer-certified installer", body: "Trained on the shingle systems we install." }, // [confirm]
		{ icon: "file", title: "Free written estimates", body: "Itemized and in your hands before any work starts." },
	],

	// ─── Contact + estimate form ───────────────────────────────────────────────
	contact: {
		eyebrow: "Contact",
		heading: "Request an estimate",
		sub: "Tell us about the roof. We'll reply within one business day with next steps.",
		successTitle: "Thanks, we got your request.",
		successBody: "Someone from the office will contact you within one business day.",
		contactPreferences: ["Phone call", "Text message", "Email"],
		detailsPlaceholder: "Leak in the back bedroom, 15-year-old shingles, storm damage…",
	},

	// ─── Checkout copy ─────────────────────────────────────────────────────────
	checkout: {
		thankYouTitle: "Payment received",
		thankYouBody: "Thank you. A receipt is on its way to your email.",
		depositNote:
			"Your final balance will be billed when the job is complete using your saved card (or sent as an invoice).",
		depositSkip: "Skip, I'll pay the final balance by invoice link",
	},

	// ─── SEO ───────────────────────────────────────────────────────────────────
	seo: {
		homeTitle: "Apollo Roofing Company | Roof repair, replacement & inspection in DFW",
		homeDescription:
			"Honest roofing in the Dallas–Fort Worth metro. Book a roof inspection, get a written estimate, and pay a fair deposit. Final balance billed when the job is done.",
		estimateTitle: "Request a roofing estimate | Apollo Roofing",
		estimateDescription:
			"Tell us about your roof and get a free written estimate from Apollo Roofing within one business day.",
	},

	// ─── Admin ─────────────────────────────────────────────────────────────────
	admin: {
		title: "Final balance invoices",
	},
} as const;

export type SiteConfig = typeof siteConfig;
export type PlanConfig = SiteConfig["plans"][number];
export type PlanKey = PlanConfig["key"];
export type ServiceConfig = SiteConfig["services"][number];

export function getPlanConfig(key: string): PlanConfig | undefined {
	return siteConfig.plans.find((p) => p.key === key);
}

export function getServiceConfig(key: string): ServiceConfig | undefined {
	return siteConfig.services.find((s) => s.key === key);
}

/** Absolute URL for a path when `siteUrl` is set, otherwise the path itself. */
export function absoluteUrl(path: string): string {
	const base = siteConfig.siteUrl.replace(/\/$/, "");
	return base ? `${base}${path}` : path;
}
