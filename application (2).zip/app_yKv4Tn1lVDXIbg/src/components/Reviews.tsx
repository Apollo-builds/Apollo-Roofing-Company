import { Award, FileText, Hammer, ShieldCheck, Star, type LucideIcon } from "lucide-react";
import { fill } from "#/lib/format";
import { siteConfig } from "#/site.config";

const ICONS: Record<string, LucideIcon> = {
	shield: ShieldCheck,
	hammer: Hammer,
	award: Award,
	file: FileText,
};

function Stars({ value, size = 20 }: { value: number; size?: number }) {
	return (
		<span className="inline-flex gap-0.5" role="img" aria-label={`${value} out of 5 stars`}>
			{[1, 2, 3, 4, 5].map((n) => (
				<Star key={n} size={size} className="fill-accent text-accent" aria-hidden />
			))}
		</span>
	);
}

export function Reviews() {
	const r = siteConfig.reviews;
	return (
		<section id="reviews" className="border-t border-line bg-card/60">
			<div className="mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-24">
				<div className="grid gap-10 lg:grid-cols-[0.8fr_2fr] lg:gap-14">
					<div>
						<p className="eyebrow">{r.eyebrow}</p>
						<h2 className="display mt-3 text-5xl sm:text-6xl">{r.heading}</h2>
						<div className="mt-6 flex items-end gap-4">
							<span className="display text-8xl leading-none">{r.rating.toFixed(1)}</span>
							<div className="pb-2">
								<Stars value={r.rating} />
								<p className="mt-1 text-sm text-muted">{fill(r.countLabel, { count: r.count })}</p>
							</div>
						</div>
						{r.sample && (
							<p className="mt-4 text-sm text-muted" data-testid="sample-note">
								Sample reviews, shown for layout. Replace with real customer reviews before launch.
							</p>
						)}
					</div>

					<ul className="grid gap-5 md:grid-cols-3">
						{r.items.map((item) => (
							<li key={item.name} className="flex flex-col rounded-card border border-line bg-paper p-6">
								<Stars value={5} size={16} />
								<blockquote className="mt-3 flex-1 text-[1.02rem]">“{item.text}”</blockquote>
								<p className="mt-5 text-sm">
									<span className="font-semibold">{item.name}</span>
									<span className="text-muted"> · {item.place}</span>
								</p>
							</li>
						))}
					</ul>
				</div>

				<ul className="mt-14 grid gap-px overflow-hidden rounded-card border border-line bg-line sm:grid-cols-2 lg:grid-cols-4">
					{siteConfig.trust.map((t) => {
						const Icon = ICONS[t.icon] ?? ShieldCheck;
						return (
							<li key={t.title} className="flex gap-4 bg-paper p-5">
								<Icon size={28} className="mt-0.5 shrink-0 text-accent" aria-hidden />
								<div>
									<p className="display text-xl leading-tight">{t.title}</p>
									<p className="mt-1 text-sm text-muted">{t.body}</p>
								</div>
							</li>
						);
					})}
				</ul>
			</div>
		</section>
	);
}
