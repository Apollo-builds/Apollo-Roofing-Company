import { CircleCheck, LoaderCircle } from "lucide-react";
import { useState, type FormEvent } from "react";
import { submitEstimate, validateEstimate, type EstimateInput } from "#/lib/estimate.functions";
import { track } from "#/lib/track";
import { siteConfig } from "#/site.config";

type Errors = Partial<Record<keyof EstimateInput, string>>;

const EMPTY: EstimateInput = {
	name: "",
	email: "",
	phone: "",
	street: "",
	city: "",
	state: siteConfig.address.state,
	zip: "",
	service: "",
	details: "",
	contactPref: siteConfig.contact.contactPreferences[0],
	website: "",
};

export function EstimateForm({ idPrefix = "est" }: { idPrefix?: string }) {
	const [values, setValues] = useState<EstimateInput>(EMPTY);
	const [errors, setErrors] = useState<Errors>({});
	const [formError, setFormError] = useState<string | null>(null);
	const [busy, setBusy] = useState(false);
	const [done, setDone] = useState<{ leadId: string } | null>(null);

	const set = <K extends keyof EstimateInput>(key: K, value: EstimateInput[K]) => {
		setValues((v) => ({ ...v, [key]: value }));
		if (errors[key]) setErrors((e) => ({ ...e, [key]: undefined }));
	};

	async function onSubmit(e: FormEvent) {
		e.preventDefault();
		if (busy) return;
		setFormError(null);
		const local = validateEstimate({ ...values, email: values.email.trim().toLowerCase(), state: values.state.trim().toUpperCase() });
		if (Object.keys(local).length) {
			setErrors(local);
			setFormError("Please fix the highlighted fields.");
			const first = Object.keys(local)[0];
			document.getElementById(`${idPrefix}-${first}`)?.focus();
			return;
		}
		setBusy(true);
		try {
			const res = await submitEstimate({ data: values });
			if (res.ok) {
				if (res.leadId !== "lead_ignored") {
					track("estimate_requested", { service: res.service, event_id: res.leadId });
					track("lead", { event_id: res.leadId, content_name: res.service });
				}
				setDone({ leadId: res.leadId });
			} else {
				setErrors(res.fieldErrors ?? {});
				setFormError(res.error);
			}
		} catch {
			setFormError(
				`Something went wrong sending your request. Please try again, or call ${siteConfig.phone.display}.`,
			);
		} finally {
			setBusy(false);
		}
	}

	if (done) {
		return (
			<div
				role="status"
				data-testid="estimate-success"
				className="rounded-card border border-line bg-paper p-8 text-center"
			>
				<CircleCheck className="mx-auto text-accent" size={44} aria-hidden />
				<h3 className="display mt-3 text-4xl">{siteConfig.contact.successTitle}</h3>
				<p className="mt-2 text-muted">{siteConfig.contact.successBody}</p>
			</div>
		);
	}

	const id = (k: string) => `${idPrefix}-${k}`;
	const err = (k: keyof EstimateInput) =>
		errors[k] ? (
			<p id={`${id(k)}-err`} className="mt-1 text-sm font-medium text-accent">
				{errors[k]}
			</p>
		) : null;
	const aria = (k: keyof EstimateInput) => ({
		"aria-invalid": errors[k] ? true : undefined,
		"aria-describedby": errors[k] ? `${id(k)}-err` : undefined,
	});

	return (
		<form onSubmit={onSubmit} noValidate className="grid grid-cols-6 gap-x-4 gap-y-4" data-testid="estimate-form">
			<div className="col-span-6 sm:col-span-3">
				<label className="label" htmlFor={id("name")}>Full name</label>
				<input id={id("name")} className="field" autoComplete="name" value={values.name} onChange={(e) => set("name", e.target.value)} {...aria("name")} />
				{err("name")}
			</div>
			<div className="col-span-6 sm:col-span-3">
				<label className="label" htmlFor={id("phone")}>Phone</label>
				<input id={id("phone")} className="field" type="tel" inputMode="tel" autoComplete="tel" value={values.phone} onChange={(e) => set("phone", e.target.value)} {...aria("phone")} />
				{err("phone")}
			</div>
			<div className="col-span-6">
				<label className="label" htmlFor={id("email")}>Email</label>
				<input id={id("email")} className="field" type="email" inputMode="email" autoComplete="email" value={values.email} onChange={(e) => set("email", e.target.value)} {...aria("email")} />
				{err("email")}
			</div>

			<div className="col-span-6">
				<label className="label" htmlFor={id("street")}>Street address of the roof</label>
				<input id={id("street")} className="field" autoComplete="address-line1" value={values.street} onChange={(e) => set("street", e.target.value)} {...aria("street")} />
				{err("street")}
			</div>
			<div className="col-span-6 sm:col-span-3">
				<label className="label" htmlFor={id("city")}>City</label>
				<input id={id("city")} className="field" autoComplete="address-level2" value={values.city} onChange={(e) => set("city", e.target.value)} {...aria("city")} />
				{err("city")}
			</div>
			<div className="col-span-3 sm:col-span-1">
				<label className="label" htmlFor={id("state")}>State</label>
				<input id={id("state")} className="field uppercase" maxLength={2} autoComplete="address-level1" value={values.state} onChange={(e) => set("state", e.target.value)} {...aria("state")} />
				{err("state")}
			</div>
			<div className="col-span-3 sm:col-span-2">
				<label className="label" htmlFor={id("zip")}>ZIP</label>
				<input id={id("zip")} className="field" inputMode="numeric" autoComplete="postal-code" value={values.zip} onChange={(e) => set("zip", e.target.value)} {...aria("zip")} />
				{err("zip")}
			</div>

			<div className="col-span-6">
				<label className="label" htmlFor={id("service")}>Service</label>
				<select id={id("service")} className="field" value={values.service} onChange={(e) => set("service", e.target.value)} {...aria("service")}>
					<option value="">Choose a service…</option>
					{siteConfig.services.map((s) => (
						<option key={s.key} value={s.key}>{s.title}</option>
					))}
				</select>
				{err("service")}
			</div>
			<div className="col-span-6">
				<label className="label" htmlFor={id("details")}>Project details <span className="font-normal text-muted">(optional)</span></label>
				<textarea id={id("details")} className="field" placeholder={siteConfig.contact.detailsPlaceholder} value={values.details} maxLength={2000} onChange={(e) => set("details", e.target.value)} {...aria("details")} />
			</div>

			<fieldset className="col-span-6">
				<legend className="label">Preferred contact</legend>
				<div className="flex flex-wrap gap-x-6 gap-y-2">
					{siteConfig.contact.contactPreferences.map((p) => (
						<label key={p} className="inline-flex cursor-pointer items-center gap-2">
							<input
								type="radio"
								name={`${idPrefix}-contactPref`}
								value={p}
								checked={values.contactPref === p}
								onChange={() => set("contactPref", p)}
								className="size-4 accent-accent"
							/>
							{p}
						</label>
					))}
				</div>
				{err("contactPref")}
			</fieldset>

			{/* Honeypot: hidden from people, tempting to bots. */}
			<div aria-hidden className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
				<label htmlFor={id("website")}>Website</label>
				<input id={id("website")} name="website" tabIndex={-1} autoComplete="off" value={values.website} onChange={(e) => set("website", e.target.value)} />
			</div>

			<div className="col-span-6 mt-1">
				{formError && (
					<p role="alert" className="mb-3 rounded border border-accent/40 bg-accent/10 px-3 py-2 text-sm font-medium">
						{formError}
					</p>
				)}
				<button type="submit" className="btn w-full sm:w-auto" disabled={busy}>
					{busy ? (
						<>
							<LoaderCircle size={18} className="animate-spin" aria-hidden /> Sending…
						</>
					) : (
						siteConfig.estimateCta
					)}
				</button>
				<p className="mt-3 text-sm text-muted">We only use your details to respond to this request.</p>
			</div>
		</form>
	);
}
