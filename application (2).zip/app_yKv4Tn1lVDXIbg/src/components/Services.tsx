import { Link } from "@tanstack/react-router";
import { ArrowRight, Check, ChevronDown } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { fill, formatMoney } from "#/lib/format";
import { productAttrs, productProps, track, trackOnce } from "#/lib/track";
import type { PlanView } from "#/lib/plans.functions";
import { usePlans } from "#/lib/use-plans";
import { siteConfig, type ServiceConfig } from "#/site.config";

export function Services() {
	const plans = usePlans();
	const s = siteConfig.servicesSection;
	return (
		<section id="services" className="mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-24">
			<div className="max-w-2xl">
				<p className="eyebrow">{s.eyebrow}</p>
				<h2 className="display mt-3 text-5xl sm:text-6xl">{s.heading}</h2>
				<p className="mt-4 text-lg text-muted">{s.sub}</p>
			</div>
			<ul className="mt-12 grid gap-6 md:grid-cols-3">
				{siteConfig.services.map((service, i) => {
					const plan = plans.find((p) => p.key === service.planKey);
					return plan ? (
						<li key={service.key} className="flex">
							<ServiceCard service={service} plan={plan} index={i} />
						</li>
					) : null;
				})}
			</ul>
		</section>
	);
}

function ServiceCard({
	service,
	plan,
	index,
}: {
	service: ServiceConfig;
	plan: PlanView;
	index: number;
}) {
	const [open, setOpen] = useState(false);
	const ref = useRef<HTMLElement>(null);
	const panelId = `service-${service.key}`;

	// Seeing the card counts as viewing the product it sells (once per page load).
	useEffect(() => {
		const el = ref.current;
		if (!el || typeof IntersectionObserver === "undefined") return;
		const io = new IntersectionObserver(
			(entries) => {
				if (entries.some((e) => e.isIntersecting)) {
					trackOnce(`view_content:${plan.planId}`, "view_content", productProps(plan));
					io.disconnect();
				}
			},
			{ threshold: 0.5 },
		);
		io.observe(el);
		return () => io.disconnect();
	}, [plan]);

	function toggle() {
		const next = !open;
		setOpen(next);
		if (next) {
			track("service_viewed", { service: service.key });
			trackOnce(`view_content:${plan.planId}`, "view_content", productProps(plan));
		}
	}

	return (
		<article
			ref={ref}
			{...productAttrs(plan)}
			data-service={service.key}
			className="flex w-full flex-col rounded-card border border-line border-t-4 border-t-accent bg-card p-6"
		>
			<span className="font-display text-lg font-semibold tracking-widest text-muted">
				{String(index + 1).padStart(2, "0")}
			</span>
			<h3 className="display mt-1 text-4xl">{service.title}</h3>
			<p className="mt-3 text-muted">{service.blurb}</p>

			<p className="display mt-6 text-3xl text-accent">
				{fill(service.priceNote, { price: formatMoney(plan.price, plan.currency) })}
			</p>

			<button
				type="button"
				onClick={toggle}
				aria-expanded={open}
				aria-controls={panelId}
				className="mt-5 flex w-full items-center justify-between border-t border-line pt-4 text-left font-semibold"
			>
				What's included
				<ChevronDown size={20} aria-hidden className={`transition-transform ${open ? "rotate-180" : ""}`} />
			</button>
			<div
				id={panelId}
				className={`grid transition-[grid-template-rows] duration-200 ${open ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`}
			>
				<ul className="overflow-hidden" aria-hidden={!open}>
					{service.bullets.map((b) => (
						<li key={b} className="flex gap-2.5 pt-3 first:pt-4">
							<Check size={18} className="mt-1 shrink-0 text-accent" aria-hidden />
							<span>{b}</span>
						</li>
					))}
				</ul>
			</div>

			<div className="mt-auto pt-6">
				<Link
					to="/checkout/$planKey"
					params={{ planKey: service.planKey }}
					className="btn w-full"
					onClick={() => track("service_viewed", { service: service.key, action: "cta_click" })}
				>
					{service.cta}
					<ArrowRight size={18} aria-hidden />
				</Link>
			</div>
		</article>
	);
}
