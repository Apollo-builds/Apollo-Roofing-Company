import { useEffect, useState } from "react";
import { TRACK_EVENT, type TrackedEvent } from "#/lib/track";

/** Hidden unless the URL has ?debug=events. Lists tracked events on screen. */
export function DebugPanel() {
	const [enabled, setEnabled] = useState(false);
	const [events, setEvents] = useState<TrackedEvent[]>([]);
	const [open, setOpen] = useState(true);

	useEffect(() => {
		const on = new URLSearchParams(window.location.search).get("debug") === "events";
		setEnabled(on);
		if (!on) return;
		setEvents([...(window.__trackLog ?? [])]);
		const handler = (e: Event) => {
			const detail = (e as CustomEvent<TrackedEvent>).detail;
			setEvents((prev) => [...prev, detail]);
		};
		window.addEventListener(TRACK_EVENT, handler);
		return () => window.removeEventListener(TRACK_EVENT, handler);
	}, []);

	if (!enabled) return null;

	return (
		<aside
			aria-label="Tracked events (debug)"
			data-testid="debug-events"
			className="fixed bottom-3 left-3 z-[100] w-[min(22rem,calc(100vw-1.5rem))] rounded-card border border-white/20 bg-navy/95 text-xs text-white shadow-xl"
		>
			<button
				type="button"
				onClick={() => setOpen((o) => !o)}
				className="flex w-full items-center justify-between px-3 py-2 font-display text-sm font-semibold uppercase tracking-widest"
			>
				<span>Events ({events.length})</span>
				<span aria-hidden>{open ? "–" : "+"}</span>
			</button>
			{open && (
				<ol className="max-h-64 space-y-1.5 overflow-auto border-t border-white/15 px-3 py-2 font-mono">
					{events.length === 0 && <li className="opacity-60">No events yet.</li>}
					{events
						.slice()
						.reverse()
						.map((e, i) => (
							<li key={`${e.at}-${i}`} className="break-words">
								<span className="text-accent-soft">{e.name}</span>{" "}
								<span className="opacity-80">{JSON.stringify(e.props)}</span>
							</li>
						))}
				</ol>
			)}
		</aside>
	);
}
