import { loadWhop } from "@whop/elements";
import {
	type Appearance,
	Checkout,
	type CheckoutPaymentCompletion,
	type CheckoutSetupCompletion,
	type CheckoutWaitlistCompletion,
	CheckoutElement,
	ExpressCheckoutElement,
	WhopElements,
} from "@whop/elements-react";
import { type ReactNode, useEffect, useRef, useState } from "react";

// Browser only: loadWhop() injects the hosted SDK script. Load it once.
let loader: ReturnType<typeof loadWhop> | null = null;
function elementsLoader() {
	return (loader ??= loadWhop());
}

export const ELEMENTS_APPEARANCE: Appearance = {
	theme: { appearance: "light", accentColor: "orange", grayColor: "sand" },
	variables: { "--radius": "4px" },
};

/** <WhopElements> with the site's appearance. Render inside <ClientOnly>. */
export function ElementsRoot({ children }: { children: ReactNode }) {
	return (
		<WhopElements
			elements={elementsLoader()}
			appearance={ELEMENTS_APPEARANCE}
			onLoadError={(error, retry) => {
				console.error("[whop elements] failed to load", error);
				setTimeout(retry, 3000);
			}}
		>
			{children}
		</WhopElements>
	);
}

type PayPanelProps = {
	planId: string;
	returnUrl: string;
	metadata?: Record<string, string>;
	buyerEmail?: string;
	lockBuyerEmail?: boolean;
	onComplete: (paymentId: string) => void;
};

/** True while the element behind `ref` renders something with height. */
function useHasHeight<T extends HTMLElement>() {
	const ref = useRef<T>(null);
	const [has, setHas] = useState(true);
	useEffect(() => {
		const el = ref.current;
		if (!el || typeof ResizeObserver === "undefined") return;
		const ro = new ResizeObserver(() => setHas(el.getBoundingClientRect().height > 4));
		ro.observe(el);
		return () => ro.disconnect();
	}, []);
	return [ref, has] as const;
}

type Completion = CheckoutPaymentCompletion | CheckoutWaitlistCompletion | CheckoutSetupCompletion;

/**
 * Express wallets (Apple Pay / Google Pay) in one Checkout handle, the full
 * checkout in a second one. A handle mounts exactly one of the two elements,
 * so the same plan gets two handles. Both send the buyer to the same place.
 */
export function PayPanel({ planId, returnUrl, metadata, buyerEmail, lockBuyerEmail, onComplete }: PayPanelProps) {
	const [expressRef, hasExpress] = useHasHeight<HTMLDivElement>();
	const complete = (payload: Completion) => {
		if (payload.result === "payment") onComplete(payload.paymentId);
	};

	return (
		<div className="space-y-5">
			<div ref={expressRef} data-testid="express-checkout">
				<Checkout plan={planId} returnUrl={returnUrl} metadata={metadata} onComplete={complete}>
					<ExpressCheckoutElement />
				</Checkout>
			</div>

			{hasExpress && (
				<div className="flex items-center gap-3 text-sm text-muted" aria-hidden>
					<span className="h-px flex-1 bg-line" />
					or pay by card
					<span className="h-px flex-1 bg-line" />
				</div>
			)}

			<div data-testid="full-checkout">
				<Checkout plan={planId} returnUrl={returnUrl} metadata={metadata} onComplete={complete}>
					<CheckoutElement buyerEmail={buyerEmail} lockBuyerEmail={lockBuyerEmail} />
				</Checkout>
			</div>
		</div>
	);
}
