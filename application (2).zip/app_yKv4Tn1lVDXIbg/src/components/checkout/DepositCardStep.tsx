import {
	BrandingElement,
	PaymentElement,
	Payments,
	usePayments,
	useWhop,
} from "@whop/elements-react";
import { LoaderCircle, Lock } from "lucide-react";
import { useState } from "react";
import { createSetupIntent, getSetupIntent, type SetupIntentView } from "#/lib/deposit.functions";
import { clearPendingCard, saveCard, savePendingCard, type SavedCard } from "#/lib/checkout-state";
import { siteConfig } from "#/site.config";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

type Props = {
	/** Where Whop sends the buyer after an off-site step (3-D Secure). */
	returnUrl: string;
	initialName?: string;
	initialEmail?: string;
	onSaved: (card: SavedCard) => void;
	onSkip: () => void;
};

/**
 * Step 1 of the deposit: save a card on file with no charge. Name and email are
 * plain inputs; the card itself is collected only by Whop's PaymentElement in
 * setup mode.
 */
export function DepositCardStep({ returnUrl, initialName = "", initialEmail = "", onSaved, onSkip }: Props) {
	const [name, setName] = useState(initialName);
	const [email, setEmail] = useState(initialEmail);

	return (
		<div data-testid="deposit-step-card">
			<div className="grid gap-4 sm:grid-cols-2">
				<div>
					<label className="label" htmlFor="dep-name">Full name</label>
					<input id="dep-name" className="field" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} />
				</div>
				<div>
					<label className="label" htmlFor="dep-email">Email</label>
					<input id="dep-email" className="field" type="email" inputMode="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
				</div>
			</div>

			<div className="mt-5">
				<Payments
					accountId={siteConfig.accountId}
					mode="setup"
					currency="usd"
					setupFutureUsage="off_session"
					returnUrl={returnUrl}
				>
					<SaveCard name={name} email={email} returnUrl={returnUrl} onSaved={onSaved} />
				</Payments>
			</div>

			<p className="mt-5 text-center">
				<button type="button" className="text-link text-sm" onClick={onSkip}>
					{siteConfig.checkout.depositSkip}
				</button>
			</p>
		</div>
	);
}

function SaveCard({
	name,
	email,
	returnUrl,
	onSaved,
}: {
	name: string;
	email: string;
	returnUrl: string;
	onSaved: (card: SavedCard) => void;
}) {
	const payments = usePayments();
	const whop = useWhop();
	const [complete, setComplete] = useState(false);
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState<string | null>(null);

	const cleanEmail = email.trim().toLowerCase();
	const ready = complete && name.trim().length >= 2 && EMAIL_RE.test(cleanEmail) && !!payments && !busy;

	async function save() {
		if (!payments || busy) return;
		setBusy(true);
		setError(null);
		try {
			const { confirmationToken } = await payments.createConfirmationToken({
				billingDetails: { name: name.trim(), email: cleanEmail },
			});
			savePendingCard({ email: cleanEmail, name: name.trim() });

			const created = await createSetupIntent({
				data: { confirmationToken, email: cleanEmail, returnUrl },
			});
			if (!created.ok) throw new Error(created.error);
			let intent: SetupIntentView = created.intent;

			// A step the buyer still has to complete (for example 3-D Secure).
			if (intent.status === "requires_action" && intent.clientSecret && whop) {
				await whop.payments.handleNextAction({ clientSecret: intent.clientSecret, returnUrl });
			}

			// Wait for the setup to settle.
			for (let i = 0; i < 40 && intent.status !== "succeeded" && intent.status !== "canceled"; i++) {
				await sleep(1500);
				const polled = await getSetupIntent({ data: { id: intent.id } });
				if (polled.ok) intent = polled.intent;
			}

			if (intent.status !== "succeeded") {
				throw new Error(
					intent.status === "canceled"
						? (intent.error ?? "The card couldn't be saved. Try another card.")
						: "We're still waiting on your bank. Please try again in a moment.",
				);
			}

			const card: SavedCard = {
				email: cleanEmail,
				name: name.trim(),
				memberId: intent.memberId,
				paymentMethodId: intent.paymentMethodId,
				setupIntentId: intent.id,
				paymentLabel: intent.paymentLabel,
			};
			saveCard(card);
			clearPendingCard();
			onSaved(card);
		} catch (err) {
			const code = (err as { code?: string } | null)?.code;
			if (code === "payment_request_cancelled") {
				setError(null); // buyer closed a wallet sheet; nothing to report
			} else {
				setError(err instanceof Error ? err.message : "Something went wrong saving your card.");
			}
		} finally {
			setBusy(false);
		}
	}

	return (
		<>
			<PaymentElement onChange={(e) => setComplete(e.complete)} />
			<div className="mt-4">
				<BrandingElement />
			</div>
			{error && (
				<p role="alert" className="mt-4 rounded border border-accent/40 bg-accent/10 px-3 py-2 text-sm font-medium">
					{error}
				</p>
			)}
			<button type="button" className="btn mt-5 w-full" disabled={!ready} onClick={save}>
				{busy ? (
					<>
						<LoaderCircle size={18} className="animate-spin" aria-hidden /> Saving card…
					</>
				) : (
					<>
						<Lock size={17} aria-hidden /> Save card, no charge
					</>
				)}
			</button>
			<p className="mt-3 text-sm text-muted">
				Nothing is charged now. Your card is stored securely by Whop and used only for your final balance.
			</p>
		</>
	);
}
