import { Link } from "@tanstack/react-router";
import { ArrowRight, Check } from "lucide-react";
import { formatMoney } from "#/lib/format";
import { productAttrs } from "#/lib/track";
import { usePlan } from "#/lib/use-plans";
import { getServiceConfig, siteConfig } from "#/site.config";

/** Split section: image on one side, the featured service's pitch on the other. */
export function FeatureSplit() {
	const f = siteConfig.feature;
	const service = getServiceConfig(f.serviceKey);
	const plan = usePlan(service?.planKey ?? "");
	if (!service || !plan) return null;

	return (
		<section className="border-y border-line bg-card/60">
			<div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-20 sm:px-6 md:grid-cols-2 md:gap-16 md:py-24">
				<div className="relative">
					<div aria-hidden className="absolute -bottom-3 -left-3 hidden size-full rounded-card border-2 border-accent md:block" />
					<img
						src={siteConfig.images.inspection}
						alt={siteConfig.images.inspectionAlt}
						width={1152}
						height={864}
						loading="lazy"
						className="relative aspect-[4/3] w-full rounded-card object-cover"
					/>
				</div>

				<div {...productAttrs(plan)}>
					<p className="eyebrow">{f.eyebrow}</p>
					<h2 className="display mt-3 text-5xl sm:text-6xl">{f.heading}</h2>
					<p className="mt-5 text-lg text-muted">{f.body}</p>
					<ul className="mt-6 space-y-3">
						{f.points.map((p) => (
							<li key={p} className="flex gap-3">
								<Check size={20} className="mt-1 shrink-0 text-accent" aria-hidden />
								<span>{p}</span>
							</li>
						))}
					</ul>
					<div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3">
						<Link to="/checkout/$planKey" params={{ planKey: plan.key }} className="btn">
							{f.cta} · {formatMoney(plan.price, plan.currency)}
							<ArrowRight size={18} aria-hidden />
						</Link>
					</div>
				</div>
			</div>
		</section>
	);
}
