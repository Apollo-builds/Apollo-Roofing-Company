import { Info } from "lucide-react";
import { siteConfig } from "#/site.config";

export function Process() {
	const p = siteConfig.process;
	return (
		<section id="process" className="mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-24">
			<div className="max-w-2xl">
				<p className="eyebrow">{p.eyebrow}</p>
				<h2 className="display mt-3 text-5xl sm:text-6xl">{p.heading}</h2>
			</div>

			<ol className="mt-12 grid gap-x-8 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
				{p.steps.map((step, i) => (
					<li key={step.title} className="border-t-4 border-ink pt-5">
						<span className="display block text-6xl text-accent">{String(i + 1).padStart(2, "0")}</span>
						<h3 className="display mt-2 text-3xl">{step.title}</h3>
						<p className="mt-2 text-muted">{step.body}</p>
					</li>
				))}
			</ol>

			<aside
				className="mt-14 flex gap-4 rounded-card border border-line bg-card p-6 sm:p-8"
				aria-labelledby="how-invoices-work"
			>
				<Info className="mt-1 hidden shrink-0 text-accent sm:block" size={26} aria-hidden />
				<div className="max-w-3xl">
					<h3 id="how-invoices-work" className="display text-3xl">
						{p.explainer.heading}
					</h3>
					<div className="mt-3 space-y-3 text-muted">
						{p.explainer.body.map((para) => (
							<p key={para}>{para}</p>
						))}
					</div>
				</div>
			</aside>
		</section>
	);
}
