import { Link } from "@tanstack/react-router";
import { ArrowRight, Phone } from "lucide-react";
import { fill, formatMoney } from "#/lib/format";
import { usePlan } from "#/lib/use-plans";
import { siteConfig } from "#/site.config";

export function Hero() {
	const plan = usePlan(siteConfig.hero.secondaryPlanKey);
	const secondary = fill(siteConfig.hero.secondaryLabel, {
		price: plan ? formatMoney(plan.price, plan.currency) : "",
	});

	return (
		<section className="relative isolate overflow-hidden bg-navy text-white">
			<img
				src={siteConfig.images.hero}
				alt={siteConfig.images.heroAlt}
				width={1536}
				height={864}
				fetchPriority="high"
				className="absolute inset-0 -z-20 h-full w-full object-cover object-[70%_center]"
			/>
			{/* Dark overlay: solid on phones, fading left-to-right from md up. */}
			<div className="absolute inset-0 -z-10 bg-navy/80 md:hidden" aria-hidden />
			<div
				className="absolute inset-0 -z-10 hidden bg-linear-to-r from-navy/95 via-navy/80 to-navy/0 md:block"
				aria-hidden
			/>

			<div className="mx-auto flex min-h-[34rem] max-w-6xl flex-col justify-center px-4 py-20 sm:px-6 md:min-h-[40rem]">
				<div className="max-w-2xl">
					<p className="eyebrow !text-accent-soft">{siteConfig.hero.eyebrow}</p>
					<h1 className="display mt-4 text-[3.25rem] sm:text-7xl lg:text-[5.5rem]">
						{siteConfig.hero.headline}
					</h1>
					<p className="mt-6 max-w-xl text-lg text-white/85 sm:text-xl">{siteConfig.hero.sub}</p>

					<div className="mt-9 flex flex-col items-start gap-5 sm:flex-row sm:items-center sm:gap-8">
						<Link to="/" hash="estimate" className="btn">
							{siteConfig.estimateCta}
							<ArrowRight size={20} aria-hidden />
						</Link>
						<Link
							to="/checkout/$planKey"
							params={{ planKey: siteConfig.hero.secondaryPlanKey }}
							className="text-link on-dark text-lg"
						>
							{secondary}
						</Link>
					</div>

					<p className="mt-10 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-white/75">
						<span>{siteConfig.license}</span>
						<span aria-hidden className="hidden h-4 w-px bg-white/30 sm:block" />
						<a href={`tel:${siteConfig.phone.tel}`} className="inline-flex items-center gap-2 font-semibold text-white hover:text-accent-soft">
							<Phone size={16} aria-hidden /> {siteConfig.phone.display}
						</a>
					</p>
				</div>
			</div>
		</section>
	);
}
