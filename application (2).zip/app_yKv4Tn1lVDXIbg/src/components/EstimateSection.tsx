import { Clock, FileText, Mail, MapPin, Phone } from "lucide-react";
import { EstimateForm } from "#/components/EstimateForm";
import { siteConfig } from "#/site.config";

export function ContactDetails() {
	const a = siteConfig.address;
	return (
		<div className="rounded-card bg-navy p-7 text-white sm:p-9">
			<h3 className="display text-3xl">Talk to the office</h3>
			<ul className="mt-6 space-y-5">
				<li className="flex gap-4">
					<Phone className="mt-1 shrink-0 text-accent-soft" size={20} aria-hidden />
					<a href={`tel:${siteConfig.phone.tel}`} className="text-lg font-semibold hover:text-accent-soft">
						{siteConfig.phone.display}
					</a>
				</li>
				<li className="flex gap-4">
					<Mail className="mt-1 shrink-0 text-accent-soft" size={20} aria-hidden />
					<a href={`mailto:${siteConfig.email}`} className="break-all hover:text-accent-soft">
						{siteConfig.email}
					</a>
				</li>
				<li className="flex gap-4">
					<Clock className="mt-1 shrink-0 text-accent-soft" size={20} aria-hidden />
					<dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1">
						{siteConfig.hours.map((h) => (
							<div key={h.days} className="contents">
								<dt className="text-white/70">{h.days}</dt>
								<dd>{h.time}</dd>
							</div>
						))}
					</dl>
				</li>
				<li className="flex gap-4">
					<MapPin className="mt-1 shrink-0 text-accent-soft" size={20} aria-hidden />
					<address className="not-italic">
						{a.line1}
						<br />
						{a.city}, {a.state} {a.zip}
					</address>
				</li>
				<li className="flex gap-4">
					<FileText className="mt-1 shrink-0 text-accent-soft" size={20} aria-hidden />
					<span className="text-white/80">{siteConfig.license}</span>
				</li>
			</ul>
		</div>
	);
}

export function EstimateSection() {
	const c = siteConfig.contact;
	return (
		<section id="estimate" className="border-t border-line bg-card/60">
			<div className="mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-24">
				<div className="max-w-2xl">
					<p className="eyebrow">{c.eyebrow}</p>
					<h2 className="display mt-3 text-5xl sm:text-6xl">{c.heading}</h2>
					<p className="mt-4 text-lg text-muted">{c.sub}</p>
				</div>
				<div className="mt-12 grid gap-8 lg:grid-cols-[1fr_1.5fr] lg:items-start">
					<ContactDetails />
					<div className="rounded-card border border-line bg-paper p-6 sm:p-9">
						<EstimateForm idPrefix="est" />
					</div>
				</div>
			</div>
		</section>
	);
}
