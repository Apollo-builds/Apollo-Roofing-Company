import { Link } from "@tanstack/react-router";
import { siteConfig } from "#/site.config";

export function Footer() {
	const a = siteConfig.address;
	return (
		<footer className="bg-navy text-white/85">
			<div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr]">
				<div>
					<div className="flex items-center gap-2.5">
						<img src={siteConfig.images.logo} alt="" width={36} height={36} className="size-9 rounded-md" />
						<span className="display text-2xl text-white">{siteConfig.name}</span>
					</div>
					<p className="mt-4 max-w-sm text-white/70">{siteConfig.tagline}</p>
					<p className="mt-4 text-sm text-white/60">{siteConfig.license}</p>
				</div>

				<div>
					<h2 className="eyebrow !text-accent-soft">Contact</h2>
					<ul className="mt-3 space-y-1.5">
						<li>
							<a className="hover:text-white" href={`tel:${siteConfig.phone.tel}`}>
								{siteConfig.phone.display}
							</a>
						</li>
						<li>
							<a className="break-all hover:text-white" href={`mailto:${siteConfig.email}`}>
								{siteConfig.email}
							</a>
						</li>
						<li className="text-white/70">
							{a.line1}, {a.city}, {a.state} {a.zip}
						</li>
					</ul>
				</div>

				<div>
					<h2 className="eyebrow !text-accent-soft">Explore</h2>
					<ul className="mt-3 space-y-1.5">
						{siteConfig.nav.slice(0, 4).map((n) => (
							<li key={n.hash}>
								<Link to="/" hash={n.hash} className="hover:text-white">
									{n.label}
								</Link>
							</li>
						))}
						<li>
							<Link to="/estimate" className="hover:text-white">
								{siteConfig.estimateCta}
							</Link>
						</li>
					</ul>
				</div>
			</div>
			<div className="border-t border-white/10">
				<div className="mx-auto flex max-w-6xl flex-col gap-1 px-4 py-5 text-sm text-white/55 sm:flex-row sm:justify-between sm:px-6">
					<span>
						© {new Date().getFullYear()} {siteConfig.name}. All rights reserved.
					</span>
					<span>Payments processed securely by Whop.</span>
				</div>
			</div>
		</footer>
	);
}
