import { siteConfig } from "#/site.config";

export function Financing() {
	const f = siteConfig.financing;
	return (
		<section id="financing" className="bg-navy text-white">
			<div className="mx-auto grid max-w-6xl gap-10 px-4 py-20 sm:px-6 sm:py-24 lg:grid-cols-[1.1fr_1fr] lg:gap-16">
				<div>
					<p className="eyebrow !text-accent-soft">{f.eyebrow}</p>
					<h2 className="display mt-3 text-5xl sm:text-6xl">{f.heading}</h2>
					<p className="mt-5 max-w-xl text-lg text-white/80">{f.body}</p>
					<ul className="mt-6 flex flex-wrap gap-2" aria-label="Example financing providers">
						{f.providers.map((p) => (
							<li
								key={p}
								className="rounded border border-white/30 px-3 py-1 font-display text-lg font-semibold uppercase tracking-wider"
							>
								{p}
							</li>
						))}
					</ul>
				</div>

				<div className="self-center rounded-card bg-paper p-6 text-ink sm:p-8">
					<h3 className="display text-2xl">How it shows up</h3>
					<ol className="mt-4 space-y-4">
						{f.steps.map((step, i) => (
							<li key={step} className="flex gap-4">
								<span className="display grid size-9 shrink-0 place-items-center rounded-full bg-ink text-lg text-paper">
									{i + 1}
								</span>
								<span className="pt-1">{step}</span>
							</li>
						))}
					</ol>
					<p className="mt-6 border-t border-line pt-4 text-sm text-muted">{f.fineprint}</p>
				</div>
			</div>
		</section>
	);
}
