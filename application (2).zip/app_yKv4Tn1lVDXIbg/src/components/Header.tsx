import { Link } from "@tanstack/react-router";
import { Menu, Phone, X } from "lucide-react";
import { useEffect, useState } from "react";
import { siteConfig } from "#/site.config";

export function Header() {
	const [open, setOpen] = useState(false);

	useEffect(() => {
		if (!open) return;
		const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open]);

	return (
		<header className="sticky top-0 z-50 border-b border-line bg-paper/95 backdrop-blur-sm">
			<div className="mx-auto flex h-16 max-w-6xl items-center gap-4 px-4 sm:px-6">
				<Link to="/" className="flex shrink-0 items-center gap-2.5" aria-label={`${siteConfig.name} home`} onClick={() => setOpen(false)}>
					<img
						src={siteConfig.images.logo}
						alt=""
						width={36}
						height={36}
						className="size-9 rounded-md"
					/>
					<span className="display text-xl leading-none sm:text-2xl">{siteConfig.shortName}</span>
				</Link>

				<nav aria-label="Primary" className="ml-6 hidden items-center gap-6 lg:flex">
					{siteConfig.nav.map((item) => (
						<Link
							key={item.hash}
							to="/"
							hash={item.hash}
							className="text-[0.95rem] font-medium text-ink/80 hover:text-accent"
						>
							{item.label}
						</Link>
					))}
				</nav>

				<div className="ml-auto flex items-center gap-2 sm:gap-3">
					<a
						href={`tel:${siteConfig.phone.tel}`}
						className="hidden items-center gap-2 font-semibold hover:text-accent xl:inline-flex"
					>
						<Phone size={17} aria-hidden /> {siteConfig.phone.display}
					</a>
					<Link to="/" hash="estimate" className="btn btn-sm" onClick={() => setOpen(false)}>
						<span className="hidden sm:inline">{siteConfig.estimateCta}</span>
						<span className="sm:hidden">Estimate</span>
					</Link>
					<button
						type="button"
						className="grid size-10 place-items-center rounded border border-line lg:hidden"
						aria-label={open ? "Close menu" : "Open menu"}
						aria-expanded={open}
						aria-controls="mobile-nav"
						onClick={() => setOpen((o) => !o)}
					>
						{open ? <X size={20} /> : <Menu size={20} />}
					</button>
				</div>
			</div>

			{open && (
				<nav id="mobile-nav" aria-label="Mobile" className="border-t border-line bg-paper lg:hidden">
					<ul className="mx-auto max-w-6xl px-4 py-2 sm:px-6">
						{siteConfig.nav.map((item) => (
							<li key={item.hash} className="border-b border-line/70 last:border-0">
								<Link
									to="/"
									hash={item.hash}
									className="block py-3 text-lg font-medium"
									onClick={() => setOpen(false)}
								>
									{item.label}
								</Link>
							</li>
						))}
						<li className="py-3">
							<a href={`tel:${siteConfig.phone.tel}`} className="inline-flex items-center gap-2 font-semibold">
								<Phone size={17} aria-hidden /> {siteConfig.phone.display}
							</a>
						</li>
					</ul>
				</nav>
			)}
		</header>
	);
}
