import { MapPin } from "lucide-react";
import { siteConfig } from "#/site.config";

export function ServiceArea() {
	const a = siteConfig.serviceArea;
	return (
		<section id="service-area" className="mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-24">
			<div className="grid gap-10 md:grid-cols-[1fr_1.2fr] md:gap-16">
				<div>
					<p className="eyebrow">Service area</p>
					<h2 className="display mt-3 text-5xl sm:text-6xl">{a.heading}</h2>
					<p className="mt-5 text-lg text-muted">{a.note}</p>
				</div>
				<ul className="flex flex-wrap content-start gap-2.5" aria-label="Cities we serve">
					{a.cities.map((city) => (
						<li
							key={city}
							className="inline-flex items-center gap-1.5 rounded border border-line bg-card px-3.5 py-2 font-display text-xl font-semibold uppercase tracking-wide"
						>
							<MapPin size={16} className="text-accent" aria-hidden />
							{city}
						</li>
					))}
				</ul>
			</div>
		</section>
	);
}
