# Roofing company website template

A one-page marketing site plus Whop-powered checkout for a US roofing contractor.
Built with TanStack Start, Tailwind v4, and Whop Elements, and hosted on a Whop Website.

Shipped as "Apollo Roofing Company". Everything that makes it Apollo lives in one file.

## Rebrand it: edit `src/site.config.ts` only

| Change | Where in `site.config.ts` |
|---|---|
| Company name, tagline, phone, email, license, hours, address | top-level fields |
| Whop business id | `accountId` (`biz_…`) |
| Public site URL (used for og/canonical tags) | `siteUrl`, e.g. `"https://yourroofer.com"` |
| Hero, services, process, financing copy | `hero`, `services`, `servicesSection`, `process`, `financing` |
| Service area cities | `serviceArea` |
| Reviews and trust badges | `reviews`, `trust` (the shipped reviews are samples; replace them, then set `sample: false`) |
| Page titles and descriptions | `seo` |
| Prices and products | `plans` (see below) |

Anything marked `[confirm]` in the file is a placeholder the owner must check.

**Images** live in `public/`. Replace the files and keep the names:
`hero.png` (hero), `inspection.png` (inspection section), `logo.png` (header, footer, favicon).

**Colors and fonts** are Tailwind tokens at the top of `src/styles.css` (`@theme`).
This is the only place outside the config you might touch for a new look.

## Set up the plans

The site sells three one-time USD plans. For each, create a product and plan in Whop, then paste
the ids into `siteConfig.plans`:

| key | purpose |
|---|---|
| `inspection` | paid roof inspection |
| `deposit` | install deposit (also saves a card on file) |
| `repair` | flat-rate minor repair |

Prices shown on the site are read live from Whop (`plans.retrieve`). If Whop can't be reached,
the `fallbackPrice` in the config is shown instead. Changing a price in Whop is enough.

## The admin passcode

`/admin/invoices` is private (noindex) and locked by the `ADMIN_PASSCODE` app secret.
Set it as a Whop app secret. It is never in the code and never sent to the browser.
The server compares it in constant time, and if it is not set the page refuses to unlock.

## How it works

**Events.** `src/lib/track.ts` wraps `whop.track`. Events: `view_content`, `service_viewed`,
`initiate_checkout`, `deposit_started`, `estimate_requested` and `lead`. Add `?debug=events`
to any URL to see a live on-screen list of what fired.

**Estimate leads.** The form posts to the `submitEstimate` server function (honeypot and
server-side validation), which creates a Whop **Lead** with name, phone, address, service and
details in the lead metadata. The Leads API requires a user. If the visitor's email matches an
existing member of the business, the lead is attached to them. Otherwise it is attached to the
business owner's user and the real contact details are in the metadata. Read them there.

**Checkout.** `/checkout/<planKey>` uses only Whop Elements, with no custom card fields.
Express wallets (Apple Pay and Google Pay) and the card form are two separate `Checkout` handles.
The thank-you page shows "Payment received" only when Whop reports `status=succeeded` or the
embedded checkout's `onComplete` fired.

**Deposit flow.** Step 1 saves a card with no charge (`Payments mode="setup"`, a setup intent
created on the server). Step 2 pays the deposit with the buyer's email locked to the one from
step 1. Customers can skip step 1 and pay the final balance from an invoice link instead.

**Final invoices.** In `/admin/invoices`, enter the customer's email (or member id) and the balance.
"Auto-charge" bills the card saved at the deposit. "Send for manual payment" emails an invoice link.
Both run `invoices.create` then `invoices.send`. A draft whose send fails is voided automatically.
Whop must have finished account verification for the business before it will issue invoices.

## File map

```
src/site.config.ts           all business data and copy
src/styles.css               design tokens + shared classes (.btn, .field, .display …)
src/routes/
  __root.tsx                 layout, fonts, plans loader
  index.tsx                  home page
  estimate.tsx               stand-alone estimate page
  checkout.$planKey.tsx      checkout (inspection, deposit, repair)
  thank-you.tsx              order result
  admin.invoices.tsx         passcode-gated invoicing
src/components/              page sections, header/footer, debug panel
src/components/checkout/     Whop Elements wrappers, deposit card step
src/lib/
  whop.server.ts             server-only SDK client, env, constant-time compare
  plans.functions.ts         live plan prices
  estimate.functions.ts      estimate → Whop Lead
  deposit.functions.ts       setup intents for saving a card
  invoices.functions.ts      admin passcode, create/send/void/list invoices
  track.ts                   event helper and ?debug=events source
  seo.ts, format.ts, checkout-state.ts, use-plans.ts, request.server.ts
public/                      hero.png, inspection.png, logo.png
```

## Commands

```bash
bun run typecheck   # type check
```

Preview runs in the Whop sandbox. Publishing is done from Whop, not from this repo.
